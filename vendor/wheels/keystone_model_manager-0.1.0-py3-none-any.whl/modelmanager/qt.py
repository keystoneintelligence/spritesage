"""Optional Qt presentation. Native widgets inherit the host's font and palette."""

from threading import Event

from PySide6 import QtCore, QtWidgets

from .catalog import CATALOG, get_profile
from .comfy import verify_connection
from .config import LocalConfig, default_config, discover_installation
from .runtime import install_runtime, runtime_status
from .storage import ModelStore, require_space
from .types import Cancelled, ManagerError


def apply_palette(widget, palette):
    if not palette:
        return
    background = palette.get("dialog_bg", palette.get("window_bg", "#3C3F41"))
    foreground = palette.get("text_color", "#BBBBBB")
    field = palette.get("dialog_input_bg", palette.get("editable_value_bg", "#313335"))
    border = palette.get("placeholder_border", "#555555")
    widget.setStyleSheet(f"""
        QDialog {{ background: {background}; color: {foreground}; }}
        QLabel, QCheckBox, QGroupBox {{ color: {foreground}; background: transparent; }}
        QLineEdit, QComboBox, QSpinBox, QPlainTextEdit {{
            background: {field}; color: {foreground}; border: 1px solid {border}; padding: 5px;
        }}
        QPushButton {{ background: {palette.get('button_bg', '#555555')}; color: {foreground};
            border: 1px solid {border}; border-radius: 3px; padding: 6px 12px; }}
        QPushButton:disabled {{ color: #888888; }}
        QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid {border};
            background: {field}; }}
        QCheckBox::indicator:checked {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; }}
        QGroupBox {{ border: 1px solid {border}; margin-top: 12px; padding-top: 12px; }}
        QProgressBar {{ color: {foreground}; background: {field}; text-align: center; }}
        QProgressBar::chunk {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; }}
    """)


class _TaskWorker(QtCore.QObject):
    progress = QtCore.Signal(object)
    result = QtCore.Signal(object)
    error = QtCore.Signal(object)
    finished = QtCore.Signal()

    def __init__(self, task, cancel):
        super().__init__()
        self.task = task
        self.cancel = cancel

    @QtCore.Slot()
    def run(self):
        try:
            self.result.emit((self.task(self.progress.emit, self.cancel),))
        except Exception as error:
            self.error.emit(error)
        finally:
            self.finished.emit()


class TaskDialog(QtWidgets.QDialog):
    def __init__(self, parent, title, task, palette=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(520)
        apply_palette(self, palette)
        self.cancel_event = Event()
        self.value = None
        self.failure = None
        self.running = True
        layout = QtWidgets.QVBoxLayout(self)
        self.label = QtWidgets.QLabel("Preparing…")
        self.label.setWordWrap(True)
        self.bar = QtWidgets.QProgressBar()
        self.bar.setRange(0, 0)
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.request_cancel)
        layout.addWidget(self.label)
        layout.addWidget(self.bar)
        layout.addWidget(self.cancel_button, alignment=QtCore.Qt.AlignmentFlag.AlignRight)
        self.thread = QtCore.QThread(self)
        self.worker = _TaskWorker(task, self.cancel_event)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.update_progress)
        self.worker.result.connect(self.got_result)
        self.worker.error.connect(self.got_error)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.completed)
        QtCore.QTimer.singleShot(0, self.thread.start)

    @QtCore.Slot(object)
    def got_result(self, payload):
        self.value = payload[0]

    @QtCore.Slot(object)
    def got_error(self, error):
        self.failure = error

    @QtCore.Slot(object)
    def update_progress(self, progress):
        if self.cancel_event.is_set():
            return
        self.label.setText(progress.message)
        if progress.total:
            self.bar.setRange(0, 1000)
            self.bar.setValue(min(1000, int(progress.completed * 1000 / progress.total)))
        else:
            self.bar.setRange(0, 0)

    @QtCore.Slot()
    def completed(self):
        self.running = False
        self.accept()

    def request_cancel(self):
        self.cancel_event.set()
        self.cancel_button.setEnabled(False)
        self.label.setText("Canceling and releasing resources…")

    def reject(self):
        if self.running:
            self.request_cancel()
        else:
            super().reject()

    def closeEvent(self, event):
        if self.running:
            self.request_cancel()
            event.ignore()
        else:
            super().closeEvent(event)


def run_task(parent, title, task, palette=None):
    dialog = TaskDialog(parent, title, task, palette)
    dialog.exec()
    dialog.thread.wait()
    if dialog.failure:
        raise dialog.failure
    return dialog.value


class ModelManagerDialog(QtWidgets.QDialog):
    """The host chooses its palette and persists selected_config only on acceptance."""

    def __init__(self, config=None, parent=None, palette=None, catalog=None):
        super().__init__(parent)
        self.setWindowTitle("Local image generation")
        self.setMinimumWidth(700)
        self.resize(780, 700)
        self.palette_data = palette
        apply_palette(self, palette)
        self.catalog = tuple(catalog or CATALOG)
        self.selected_config = None
        initial_error = None
        try:
            self.initial = LocalConfig.from_dict(config)
        except ManagerError as error:
            initial_error = str(error)
            self.initial = default_config()
            config = None
        self.verified_config = self.initial.to_dict() if config else None
        layout = QtWidgets.QVBoxLayout(self)
        intro = QtWidgets.QLabel(
            initial_error
            or "Generate images on your computer. Choose a supported model and set up its local engine once."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.mode = QtWidgets.QComboBox()
        self.mode.addItem("Install local generation (recommended)", "managed")
        self.mode.addItem("Use an existing ComfyUI installation", "existing")
        layout.addWidget(self.mode)
        self.explanation = QtWidgets.QLabel()
        self.explanation.setWordWrap(True)
        layout.addWidget(self.explanation)

        locations = QtWidgets.QFormLayout()
        self.runtime_edit, runtime_row = self.path_row("Choose the local runtime folder")
        self.model_edit, model_row = self.path_row("Choose the model storage folder")
        self.python_edit, self.python_row = self.path_row(
            "Choose ComfyUI's Python executable", executable=True
        )
        self.python_label = QtWidgets.QLabel("Python executable:")
        locations.addRow("Runtime folder:", runtime_row)
        locations.addRow("Model storage:", model_row)
        locations.addRow(self.python_label, self.python_row)
        layout.addLayout(locations)

        self.model_combo = QtWidgets.QComboBox()
        for profile in self.catalog:
            self.model_combo.addItem(profile.name, profile.id)
        layout.addWidget(self.model_combo)
        self.details = QtWidgets.QLabel()
        self.details.setWordWrap(True)
        layout.addWidget(self.details)
        self.license_link = QtWidgets.QLabel()
        self.license_link.setOpenExternalLinks(True)
        layout.addWidget(self.license_link)
        self.license_check = QtWidgets.QCheckBox(
            "I have reviewed the model license and my use is permitted."
        )
        layout.addWidget(self.license_check)

        self.advanced = QtWidgets.QGroupBox("Generation settings")
        advanced_layout = QtWidgets.QFormLayout(self.advanced)
        self.hardware = QtWidgets.QComboBox()
        self.hardware.addItem("Automatic (detect older NVIDIA GPUs)", "auto")
        self.hardware.addItem("Compatibility · older NVIDIA / low VRAM", "compatibility")
        self.hardware.addItem("CPU only · very slow", "cpu")
        self.width = QtWidgets.QSpinBox()
        self.height = QtWidgets.QSpinBox()
        for field in (self.width, self.height):
            field.setRange(256, 2048)
            field.setSingleStep(64)
        sizes = QtWidgets.QWidget()
        row = QtWidgets.QHBoxLayout(sizes)
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self.width)
        row.addWidget(QtWidgets.QLabel("×"))
        row.addWidget(self.height)
        self.steps = QtWidgets.QSpinBox()
        self.steps.setRange(1, 100)
        advanced_layout.addRow("Hardware:", self.hardware)
        advanced_layout.addRow("Image size:", sizes)
        advanced_layout.addRow("Steps:", self.steps)
        hint = QtWidgets.QLabel(
            "Start at 512 × 512. Reference edits preserve the first image's proportions. Older GPUs can take several minutes per image."
        )
        hint.setWordWrap(True)
        advanced_layout.addRow(hint)
        layout.addWidget(self.advanced)
        self.status_label = QtWidgets.QLabel()
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)
        self.cache_note = QtWidgets.QLabel()
        self.cache_note.setWordWrap(True)
        layout.addWidget(self.cache_note)
        actions = QtWidgets.QHBoxLayout()
        self.setup_button = QtWidgets.QPushButton("Install runtime and model")
        self.verify_button = QtWidgets.QPushButton("Verify setup")
        self.remove_button = QtWidgets.QPushButton("Remove model…")
        self.disconnect_button = QtWidgets.QPushButton("Disconnect")
        for button in (
            self.setup_button,
            self.verify_button,
            self.remove_button,
            self.disconnect_button,
        ):
            actions.addWidget(button)
        layout.addLayout(actions)
        layout.addStretch()
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Cancel)
        self.use_button = buttons.addButton(
            "Use this model", QtWidgets.QDialogButtonBox.ButtonRole.AcceptRole
        )
        buttons.rejected.connect(self.reject)
        self.use_button.clicked.connect(self.use_model)
        layout.addWidget(buttons)

        self.runtime_edit.setText(self.initial.runtime_root)
        self.model_edit.setText(self.initial.model_root)
        self.python_edit.setText(self.initial.python_executable)
        self.mode.setCurrentIndex(self.mode.findData(self.initial.mode))
        self.model_combo.setCurrentIndex(max(0, self.model_combo.findData(self.initial.model_id)))
        self.hardware.setCurrentIndex(self.hardware.findData(self.initial.hardware))
        self.width.setValue(self.initial.width)
        self.height.setValue(self.initial.height)
        self.steps.setValue(self.initial.steps)
        self.license_check.setChecked(self.initial.accepted_license == self.initial.model_id)
        self.mode.currentIndexChanged.connect(self.mode_changed)
        self.model_combo.currentIndexChanged.connect(self.refresh)
        self.runtime_edit.editingFinished.connect(self.locate_existing)
        for field in (self.runtime_edit, self.model_edit, self.python_edit):
            field.textChanged.connect(self.refresh)
        for field in (self.width, self.height, self.steps):
            field.valueChanged.connect(self.refresh)
        self.hardware.currentIndexChanged.connect(self.refresh)
        self.license_check.toggled.connect(self.refresh)
        self.setup_button.clicked.connect(self.install)
        self.verify_button.clicked.connect(self.verify)
        self.remove_button.clicked.connect(self.remove)
        self.disconnect_button.clicked.connect(self.disconnect)
        self.mode_changed()

    def path_row(self, title, executable=False):
        edit = QtWidgets.QLineEdit()
        button = QtWidgets.QPushButton("Browse…")
        row = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(edit)
        layout.addWidget(button)

        def browse():
            if executable:
                value, _ = QtWidgets.QFileDialog.getOpenFileName(self, title, edit.text())
            else:
                value = QtWidgets.QFileDialog.getExistingDirectory(self, title, edit.text())
            if value:
                edit.setText(value)
                if edit is self.runtime_edit:
                    self.locate_existing()

        button.clicked.connect(browse)
        return edit, row

    def config(self):
        values = self.initial.to_dict()
        values.update(
            runtime_root=self.runtime_edit.text().strip(),
            model_root=self.model_edit.text().strip(),
            python_executable=self.python_edit.text().strip(),
            mode=self.mode.currentData(),
            model_id=self.model_combo.currentData(),
            hardware=self.hardware.currentData(),
            width=self.width.value(),
            height=self.height.value(),
            steps=self.steps.value(),
            accepted_license=(
                self.model_combo.currentData() if self.license_check.isChecked() else ""
            ),
        )
        return LocalConfig.from_dict(values)

    def mode_changed(self):
        existing = self.mode.currentData() == "existing"
        self.python_row.setVisible(existing)
        self.python_label.setVisible(existing)
        self.setup_button.setVisible(not existing)
        self.disconnect_button.setVisible(existing)
        self.explanation.setText(
            "Locate ComfyUI and its model files. We verify and reuse them without moving, updating, or deleting the originals."
            if existing
            else "Download a separate local engine and model. No Python installation is needed. Automatic setup supports Windows x64 with an NVIDIA GPU. Choose folders with about 30 GiB free for this first model and runtime."
        )
        self.refresh()

    def locate_existing(self):
        if self.mode.currentData() != "existing":
            return
        try:
            comfy, python, models = discover_installation(self.runtime_edit.text())
        except ManagerError:
            return
        self.runtime_edit.setText(str(comfy))
        if python:
            self.python_edit.setText(str(python))
        self.model_edit.setText(str(models))
        self.refresh()

    def refresh(self):
        profile = get_profile(self.model_combo.currentData())
        self.details.setText(
            f"Text-to-image, reference editing, and transparency · {profile.download_bytes / 1024**3:.1f} GiB of model files.\n{profile.license_summary}"
        )
        self.license_link.setText(
            f'<a style="color: {self.palette_data.get("link_color", "#75B9EF") if self.palette_data else self.palette().color(self.foregroundRole()).name()}" '
            f'href="{profile.license_url}">Read {profile.license_name}</a>'
        )
        self.use_button.setEnabled(False)
        self.remove_button.setEnabled(False)
        try:
            config = self.config()
            store = ModelStore(config.model_root, config.state_root)
            status = store.status(profile)
            runtime = runtime_status(config)
            self.status_label.setText(f"Engine: {runtime}    ·    Model: {status}")
            self.remove_button.setEnabled(store.owns(profile))
            self.use_button.setEnabled(
                runtime == "Ready"
                and status == "Ready"
                and self.license_check.isChecked()
                and self.verified_config is not None
                and self.connection_key(config.to_dict())
                == self.connection_key(self.verified_config)
            )
            self.cache_note.setText(
                "This cache may be shared by other applications. Removal affects this model revision for all of them."
                if store.owns(profile)
                else "Existing files are reused after verification. Externally installed files are never removed by Model Manager."
            )
        except (ManagerError, OSError) as error:
            self.status_label.setText(str(error))

    @staticmethod
    def connection_key(config):
        return {
            key: config.get(key)
            for key in (
                "runtime_root",
                "model_root",
                "python_executable",
                "mode",
                "model_id",
                "hardware",
            )
        }

    def _perform(self, task, title):
        try:
            config = self.config()
            if not config.accepted_license:
                raise ManagerError(
                    "Review the model license and confirm that your use is permitted before continuing."
                )
            run_task(
                self,
                title,
                lambda progress, cancel: task(config, progress, cancel),
                self.palette_data,
            )
            self.verified_config = config.to_dict()
        except Cancelled:
            pass
        except Exception as error:
            QtWidgets.QMessageBox.warning(self, title, str(error))
        self.refresh()

    def install(self):
        def task(config, progress, cancel):
            profile = get_profile(config.model_id)
            store = ModelStore(config.model_root, config.state_root)
            if store.status(profile) != "Ready":
                require_space(store.root, store.remaining_bytes(profile))
            install_runtime(config, progress, cancel)
            store.install(profile, progress, cancel)
            verify_connection(config, progress, cancel)

        self._perform(task, "Installing local generation")

    def verify(self):
        self._perform(verify_connection, "Verifying local generation")

    def use_model(self):
        if self.use_button.isEnabled():
            self.selected_config = self.config().to_dict()
            self.accept()

    def remove(self):
        config = self.config()
        profile = get_profile(config.model_id)
        answer = QtWidgets.QMessageBox.question(
            self,
            "Remove downloaded model",
            f"Remove Model Manager's files for {profile.name} from this cache? Other applications using the same cache will need them downloaded again. Externally installed files are kept.",
        )
        if answer == QtWidgets.QMessageBox.StandardButton.Yes:
            try:
                ModelStore(config.model_root, config.state_root).remove(profile)
            except Exception as error:
                QtWidgets.QMessageBox.warning(self, "Remove model", str(error))
            self.refresh()

    def disconnect(self):
        self.selected_config = default_config().to_dict()
        self.accept()
