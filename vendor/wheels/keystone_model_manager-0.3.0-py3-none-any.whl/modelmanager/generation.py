"""Host-neutral recipe orchestration, with sequential GPU stages."""

from contextlib import ExitStack
from dataclasses import replace
from pathlib import Path
import tempfile

from filelock import FileLock, Timeout

from . import comfy, prompt_runtime
from .catalog import get_profile
from .components import ComponentStore, component_status
from .config import LocalConfig
from .enhancer import PromptEngine, EnhancementError
from .storage import ModelStore
from .types import ManagerError, check_cancel, emit


def generate_image(
    config: LocalConfig,
    prompt: str,
    references: list[str],
    output_folder,
    progress=None,
    cancel=None,
    *,
    constraints=(),
):
    config.validate()
    profile = get_profile(config.model_id)
    # Validate unsupported requests before spending time on prompt enhancement.
    comfy.build_workflow(config, prompt, references)
    check_cancel(cancel)
    store = ModelStore(config.model_root, config.state_root)
    if store.status(profile) != "Ready":
        raise ManagerError("Local image files need verification in Manage local models.")
    lock_path = Path(tempfile.gettempdir()) / "keystone-modelmanager-generation.lock"
    try:
        with ExitStack() as stack:
            stack.enter_context(FileLock(str(lock_path), timeout=0))
            core_lease = None
            if store.owns(profile):
                core_lease = stack.enter_context(
                    FileLock(str(store.root / ".modelmanager-download.lock"), timeout=0)
                )
            effective = prompt
            if config.enhance_prompts and profile.enhancement:
                components = ComponentStore(config)
                shared_lock = (
                    core_lease if components.root.resolve() == store.root.resolve() else None
                )
                stack.enter_context(components.lease(profile, shared_lock))
                if (
                    component_status(config, profile) != "Ready"
                    or prompt_runtime.status(config) != "Ready"
                ):
                    raise ManagerError(
                        "Prompt tools need installation or verification. Open Manage local models, or disable automatic prompt improvement under Advanced."
                    )
                prompt_runtime.verify_prompts()
                engine_root = prompt_runtime.locate(config)
                if (
                    engine_root == prompt_runtime.managed_root(config)
                    and not config.helper_runtime_root
                ):
                    stack.enter_context(
                        FileLock(str(engine_root.parent / ".modelmanager-runtime.lock"), timeout=0)
                    )
                effective = PromptEngine(config, progress, cancel).rewrite(
                    prompt, references, constraints
                )
                if constraints:
                    effective += "\n\n" + " ".join(constraints)
            check_cancel(cancel)
            emit(progress, "Generating image · preparing local image engine…")
            with comfy.ComfyEngine(config, progress, cancel, cache_lease=core_lease) as engine:
                return engine.generate(effective, references, output_folder)
    except EnhancementError as error:
        # A per-request continuation; the saved configuration is never changed.
        def original(progress=None, cancel=None):
            return generate_image(
                replace(config, enhance_prompts=False),
                prompt,
                references,
                output_folder,
                progress,
                cancel,
                constraints=constraints,
            )

        error.generate_original = original
        raise
    except Timeout as error:
        raise ManagerError(
            "Another local generation or installation is using these resources. Wait for it to finish and retry."
        ) from error
