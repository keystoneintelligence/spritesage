"""Portable, checksum-pinned llama.cpp. Existing installations are borrowed."""

import hashlib
import json
import platform
import sys
from importlib.resources import files
from pathlib import Path

from filelock import FileLock

from .components import installation_roots
from .runtime import clean_environment, run_command, safe_extract
from .storage import ModelStore, atomic_json, download, file_digest, read_json, require_space
from .types import ManagerError, check_cancel

RUNTIME_ID = "llama-b11160-cuda12"
RUNTIME_FOLDER = "b11160-cuda12"
MANIFEST = json.loads(
    files("modelmanager").joinpath("data/llama-runtime.json").read_text(encoding="utf-8")
)
MANIFEST_ID = hashlib.sha256(json.dumps(MANIFEST, sort_keys=True).encode()).hexdigest()


def managed_root(config):
    base = (
        Path(config.runtime_root)
        if config.mode == "managed"
        else Path(config.state_root).parent / "runtime"
    )
    return base / "llama.cpp" / RUNTIME_FOLDER


def locate(config):
    if config.helper_runtime_root:
        return Path(config.helper_runtime_root)
    managed = managed_root(config)
    if (managed / "llama-server.exe").is_file():
        return managed
    for base in installation_roots(config):
        path = base / "llama.cpp" / RUNTIME_FOLDER
        if (path / "llama-server.exe").is_file():
            return path
    return managed


def _receipt(config, root):
    key = hashlib.sha256(str(root.resolve()).encode()).hexdigest()[:24]
    return Path(config.state_root) / "verified" / f"llama-{key}.json"


def _stamps(root):
    return {name: ModelStore._stamp(root / name) for name in MANIFEST["files"]}


def status(config):
    root = locate(config)
    try:
        if any(
            (root / name).stat().st_size != item["size"] for name, item in MANIFEST["files"].items()
        ):
            return "Incomplete"
        receipt = read_json(_receipt(config, root))
        if receipt.get("manifest") == MANIFEST_ID and receipt.get("files") == _stamps(root):
            return "Ready"
        return "Needs verification"
    except OSError:
        return "Not installed"


def verify(config, progress=None, cancel=None):
    root = locate(config)
    stamps = {}
    for name, item in MANIFEST["files"].items():
        check_cancel(cancel)
        path = root / name
        if not path.is_file() or path.stat().st_size != item["size"]:
            raise ManagerError(
                "The prompt engine is incomplete. Install prompt tools or select a complete engine under Advanced."
            )
        before = ModelStore._stamp(path)
        if (
            file_digest(path, progress, cancel) != item["sha256"]
            or ModelStore._stamp(path) != before
        ):
            raise ManagerError(
                "The prompt engine does not match its pinned release. Choose another engine folder; no existing files were changed."
            )
        stamps[name] = before
    run_command([root / "llama-server.exe", "--version"], cancel=cancel, env=clean_environment())
    atomic_json(_receipt(config, root), {"manifest": MANIFEST_ID, "files": stamps})
    return root


def space_bytes(config):
    if status(config) in {"Ready", "Needs verification"}:
        return 0
    return sum(a["size"] for a in MANIFEST["assets"]) + sum(
        f["size"] for f in MANIFEST["files"].values()
    )


def install(config, progress=None, cancel=None):
    if status(config) == "Ready":
        return locate(config)
    if status(config) == "Needs verification":
        return verify(config, progress, cancel)
    if sys.platform != "win32" or platform.machine().lower() not in {"amd64", "x86_64"}:
        raise ManagerError("Automatic prompt engine setup currently supports Windows x64.")
    root = locate(config)
    if config.helper_runtime_root or root != managed_root(config):
        raise ManagerError(
            "The selected prompt engine is incomplete. Clear its Advanced override to install a managed copy."
        )
    checker = ModelStore(root.parent, config.state_root)
    checker._assert_managed_path(root)
    require_space(root.parent, space_bytes(config))
    root.parent.mkdir(parents=True, exist_ok=True)
    with FileLock(str(root.parent / ".modelmanager-runtime.lock"), timeout=0):
        marker = root / ".modelmanager-owned.json"
        if root.exists() and any(root.iterdir()) and read_json(marker).get("id") != RUNTIME_ID:
            raise ManagerError(
                "The prompt engine folder contains unowned files. Select another engine location."
            )
        root.mkdir(parents=True, exist_ok=True)
        atomic_json(marker, {"id": RUNTIME_ID})
        downloads = root.parent / "downloads"
        for asset in MANIFEST["assets"]:
            check_cancel(cancel)
            archive = downloads / asset["name"]
            download(
                asset["browser_download_url"],
                archive,
                asset["size"],
                asset["digest"].split(":", 1)[1],
                progress,
                cancel,
            )
            safe_extract(archive, root)
        return verify(config, progress, cancel)


def verify_prompts():
    source = json.loads(
        files("modelmanager").joinpath("data/prompt-source.json").read_text(encoding="utf-8")
    )
    for name, expected in source["sha256"].items():
        content = files("modelmanager").joinpath(f"data/{name}").read_bytes()
        if hashlib.sha256(content).hexdigest() != expected:
            raise ManagerError(
                "Bundled prompt instructions failed verification. Reinstall Model Manager."
            )
