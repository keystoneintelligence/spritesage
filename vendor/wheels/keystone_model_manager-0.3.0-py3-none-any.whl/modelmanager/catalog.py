from dataclasses import dataclass

from .types import ManagerError


@dataclass(frozen=True)
class ModelFile:
    path: str
    size: int
    sha256: str


@dataclass(frozen=True)
class ModelComponent:
    id: str
    repository: str
    revision: str
    files: tuple[ModelFile, ...]
    license_url: str


@dataclass(frozen=True)
class PromptEnhancement:
    id: str
    runtime: str
    creation: ModelComponent
    editing: ModelComponent

    @property
    def components(self):
        return (self.creation, self.editing)


QWEN_PROMPTS = PromptEnhancement(
    id="qwen-image-21-prompts-v1",
    runtime="llama-b11160-cuda12",
    creation=ModelComponent(
        "qwen-image-21-pe-t2i-q4",
        "prithivMLmods/Qwen-Image-2.1-PE-T2I-GGUF",
        "e18d4a3e0830ab157770738b16830e6fcf5f57d4",
        (
            ModelFile(
                "Qwen-Image-2.1-PE-T2I.Q4_K_M.gguf",
                5629108864,
                "340feb42c784e35b704a0f0d8d1c679a3fe60437bd9ea44a7a6fd2d730470506",
            ),
        ),
        "https://huggingface.co/Qwen/Qwen-Image-2.1-PE-T2I/blob/main/LICENSE",
    ),
    editing=ModelComponent(
        "qwen-image-21-pe-i2i-q4",
        "prithivMLmods/Qwen-Image-2.1-PE-I2I-GGUF",
        "55b9c1a326599e142d59bcad8715d5601ccf8daa",
        (
            ModelFile(
                "Qwen-Image-2.1-PE-I2I.Q4_K_M.gguf",
                5629108864,
                "a5c6cb28cbaf838834d1335c8392619af5809d9fe95d0ebd321e15751866dfe9",
            ),
            ModelFile(
                "Qwen-Image-2.1-PE-I2I.mmproj-bf16.gguf",
                921704608,
                "8dedb71dbc3092dc47de9108ad373d68a12854e2527d59bd9399601738f3bce1",
            ),
        ),
        "https://huggingface.co/Qwen/Qwen-Image-2.1-PE-I2I/blob/main/LICENSE",
    ),
)


@dataclass(frozen=True)
class ModelProfile:
    id: str
    name: str
    repository: str
    revision: str
    files: tuple[ModelFile, ...]
    capabilities: tuple[str, ...]
    license_name: str
    license_url: str
    license_summary: str
    runtime: str
    workflow: str
    max_references: int = 10
    description: str = "Local image generation."
    default_width: int = 512
    default_height: int = 512
    default_steps: int = 25
    enhancement: PromptEnhancement | None = None

    @property
    def download_bytes(self):
        return sum(item.size for item in self.files)


CATALOG = (
    ModelProfile(
        id="qwen-image-2.1-int8",
        name="Qwen Image 2.1 · INT8",
        repository="Comfy-Org/Qwen-Image-2.1",
        revision="ace0edeb3791a594ddfa36ed5f41a178a394e921",
        files=(
            ModelFile(
                "diffusion_models/qwen_image_2.1_int8_convrot.safetensors",
                7256783064,
                "cb74113cb03faecd79611b01fd7fd642f0aa60d6f0b95086abee214d75eaa57d",
            ),
            ModelFile(
                "text_encoders/qwen3vl_8b_int8_convrot.safetensors",
                9350798360,
                "8bfd0f6e12abf2d2d697ecc888e5e90b0d6741d6708f05799f53afa560452e8f",
            ),
            ModelFile(
                "vae/qwen_image_2.1_vae_bf16.safetensors",
                675509688,
                "bb21f7473051e1ac368515dd3f2e15cd44d7a11748ee8823e1ddca3e4876b7c9",
            ),
        ),
        capabilities=("text_to_image", "image_edit", "multi_reference", "rgba"),
        runtime="comfy-image-v1",
        workflow="qwen_image_21",
        enhancement=QWEN_PROMPTS,
        description="Create images and edit them with reference images. Supports transparent backgrounds.",
        license_name="Qwen Research License",
        license_url="https://huggingface.co/Qwen/Qwen-Image-2.1/blob/main/LICENSE",
        license_summary="Research/evaluation only. Commercial use requires a separate Qwen license.",
    ),
)


def get_profile(model_id: str) -> ModelProfile:
    for profile in CATALOG:
        if profile.id == model_id:
            return profile
    raise ManagerError(
        f"The local model {model_id!r} is not in this application's supported catalog."
    )
