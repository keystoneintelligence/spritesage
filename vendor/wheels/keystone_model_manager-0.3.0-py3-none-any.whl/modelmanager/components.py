"""Recipe dependencies: pinned files, borrowed locations, and shared ownership."""

import hashlib
from contextlib import contextmanager
from pathlib import Path

from filelock import FileLock, Timeout

from .storage import ModelStore, atomic_json, read_json
from .types import ManagerError


def installation_roots(config):
    """Discover only relative to paths selected by the user."""
    result = []
    for raw in (config.runtime_root, config.model_root):
        path = Path(raw)
        for candidate in (path, path.parent, path.parent.parent):
            if candidate not in result:
                result.append(candidate)
    return result


class ComponentStore(ModelStore):
    def __init__(self, config):
        base = (
            Path(config.model_root)
            if config.mode == "managed"
            else Path(config.state_root).parent / "models"
        )
        root = Path(config.helper_model_root) if config.helper_model_root else base / "components"
        super().__init__(root, config.state_root)
        self.config = config

    def _roots(self, profile):
        roots = list(super()._roots(profile))
        if not self.config.helper_model_root:
            for base in installation_roots(self.config):
                roots.append(base / "prompt-enhancement" / "gguf")
        return tuple(roots)

    @property
    def owners_path(self):
        return self.root / ".modelmanager-recipes.json"

    def owner_id(self, profile):
        return hashlib.sha256(f"{self.state.resolve()}:{profile.id}".encode()).hexdigest()

    def remember_recipe(self, profile):
        if not profile.enhancement:
            return
        self.root.mkdir(parents=True, exist_ok=True)
        with FileLock(str(self.root / ".modelmanager-recipes.lock"), timeout=5):
            owners = read_json(self.owners_path)
            owners[self.owner_id(profile)] = [
                f"{c.id}/{c.revision}" for c in profile.enhancement.components
            ]
            atomic_json(self.owners_path, owners)

    @contextmanager
    def lease(self, profile, shared_lock=None):
        self.remember_recipe(profile)
        if shared_lock is not None:
            yield
            return
        try:
            with FileLock(str(self.root / ".modelmanager-download.lock"), timeout=0):
                yield
        except Timeout as error:
            raise ManagerError(
                "Prompt tools are in use by another Model Manager operation. Try again when it finishes."
            ) from error

    def release_recipe(self, profile):
        """Forget this consumer. Keep shared caches until explicit maintenance."""
        if not self.root.exists():
            return
        with FileLock(str(self.root / ".modelmanager-recipes.lock"), timeout=0):
            owners = read_json(self.owners_path)
            owners.pop(self.owner_id(profile), None)
            atomic_json(self.owners_path, owners)
        # Components are shared across applications. Retaining unreferenced files
        # also protects apps with old receipts. Never infer permission to delete.


def component_status(config, profile):
    if not profile.enhancement:
        return "Ready"
    store = ComponentStore(config)
    statuses = [store.status(c) for c in profile.enhancement.components]
    if all(s == "Ready" for s in statuses):
        return "Ready"
    if all(s in {"Ready", "Needs verification"} for s in statuses):
        return "Needs verification"
    return "Not installed" if all(s == "Not installed" for s in statuses) else "Incomplete"


def component_bytes(config, profile):
    store = ComponentStore(config)
    return (
        sum(store.remaining_bytes(c) for c in profile.enhancement.components)
        if profile.enhancement
        else 0
    )
