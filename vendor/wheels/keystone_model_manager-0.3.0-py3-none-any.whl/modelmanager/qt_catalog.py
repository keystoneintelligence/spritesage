"""A model-first catalog with optional installation and generation controls."""

from dataclasses import replace
from html import escape

from PySide6 import QtCore, QtWidgets

from .catalog import CATALOG, get_profile
from .config import LocalConfig, default_config, discover_installation
from .installation import (
    install_model,
    verify_model,
    check_support,
    RUNTIME_SPACE,
    install_prompt_tools,
    enhancement_status,
    enhancement_size,
)
from .components import ComponentStore
from .library import ModelLibrary, connection_key
from .qt_tasks import apply_palette, run_task
from .runtime import runtime_status
from .storage import ModelStore
from .types import Cancelled, ManagerError

CAPABILITY_LABELS = {
    "text_to_image": "Text to image",
    "image_edit": "Reference editing",
    "multi_reference": "Multiple references",
    "rgba": "Transparency",
}


class ModelManagerDialog(QtWidgets.QDialog):
    """Install models independently. Only Use model changes the host's selection."""

    def __init__(self, config=None, parent=None, palette=None, catalog=None):
        super().__init__(parent)
        self.setWindowTitle("Local models")
        self.setMinimumWidth(780)
        self.resize(860, 460)
        self.palette_data = palette
        apply_palette(self, palette)
        self.catalog = tuple(CATALOG if catalog is None else catalog)
        self.selected_config = None
        initial_error = ""
        try:
            self.initial = LocalConfig.from_dict(config)
        except ManagerError as error:
            initial_error = str(error)
            self.initial = default_config()
            config = None
        self.active_id = self.initial.model_id if config else None
        self.library = ModelLibrary(self.initial.state_root)
        self.drafts = {p.id: self.library.config_for(p, self.initial) for p in self.catalog}
        self.verified = {}
        if config and self.initial.model_id in self.drafts:
            self.drafts[self.initial.model_id] = self.initial
            profile = get_profile(self.initial.model_id)
            self.verified[profile.id] = connection_key(self.initial, profile)
        self.current_id = None
        self.loading = False
        self.action = None

        layout = QtWidgets.QVBoxLayout(self)
        intro = QtWidgets.QLabel(
            initial_error or "Choose a model to install or use. Models are downloaded individually."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)
        body = QtWidgets.QHBoxLayout()
        self.model_list = QtWidgets.QListWidget()
        self.model_list.setMinimumWidth(230)
        self.model_list.setMaximumWidth(300)
        for profile in self.catalog:
            item = QtWidgets.QListWidgetItem(profile.name)
            item.setData(QtCore.Qt.ItemDataRole.UserRole, profile.id)
            self.model_list.addItem(item)
        body.addWidget(self.model_list, 1)
        self.detail_panel = QtWidgets.QWidget()
        detail = QtWidgets.QVBoxLayout(self.detail_panel)
        detail.setContentsMargins(10, 0, 0, 0)
        self.title_label = QtWidgets.QLabel()
        title_font = self.title_label.font()
        title_font.setPointSize(title_font.pointSize() + 3)
        title_font.setBold(True)
        self.title_label.setFont(title_font)
        self.title_label.setWordWrap(True)
        self.description = QtWidgets.QLabel()
        self.description.setWordWrap(True)
        self.capabilities = QtWidgets.QLabel()
        self.capabilities.setWordWrap(True)
        self.status_label = QtWidgets.QLabel()
        self.status_label.setWordWrap(True)
        self.install_note = QtWidgets.QLabel()
        self.install_note.setWordWrap(True)
        for widget in (
            self.title_label,
            self.description,
            self.capabilities,
            self.status_label,
            self.install_note,
        ):
            detail.addWidget(widget)
        self.license_summary = QtWidgets.QLabel()
        self.license_summary.setWordWrap(True)
        self.license_link = QtWidgets.QLabel()
        self.license_link.setOpenExternalLinks(True)
        self.license_check = QtWidgets.QCheckBox(
            "I have reviewed this model's license and my use is permitted."
        )
        detail.addWidget(self.license_summary)
        detail.addWidget(self.license_link)
        detail.addWidget(self.license_check)

        actions = QtWidgets.QHBoxLayout()
        self.primary_button = QtWidgets.QPushButton("Install model")
        self.primary_button.setObjectName("installModel")
        self.primary_button.setDefault(True)
        self.options_button = QtWidgets.QToolButton()
        self.options_button.setText("Model options")
        self.options_button.setPopupMode(QtWidgets.QToolButton.ToolButtonPopupMode.InstantPopup)
        menu = QtWidgets.QMenu(self.options_button)
        self.verify_action = menu.addAction("Verify again")
        self.remove_action = menu.addAction("Remove downloaded model…")
        self.disconnect_action = menu.addAction("Disconnect existing installation")
        self.options_button.setMenu(menu)
        actions.addWidget(self.primary_button, 1)
        actions.addWidget(self.options_button)
        detail.addLayout(actions)
        self.existing_button = QtWidgets.QPushButton("Use an existing installation…")
        self.existing_button.setObjectName("existingModel")
        detail.addWidget(self.existing_button, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)
        self.enhancement_button = QtWidgets.QPushButton("Add prompt enhancement")
        self.enhancement_button.hide()
        detail.addWidget(self.enhancement_button, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)

        self.advanced_toggle = QtWidgets.QToolButton()
        self.advanced_toggle.setText("Advanced")
        self.advanced_toggle.setCheckable(True)
        self.advanced_toggle.setToolButtonStyle(QtCore.Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.advanced_toggle.setArrowType(QtCore.Qt.ArrowType.RightArrow)
        detail.addWidget(self.advanced_toggle, alignment=QtCore.Qt.AlignmentFlag.AlignLeft)
        self.advanced = QtWidgets.QScrollArea()
        self.advanced.setWidgetResizable(True)
        self.advanced.setMinimumHeight(270)
        self.advanced.setMaximumHeight(340)
        self.advanced.hide()
        fields = QtWidgets.QWidget()
        fields.setObjectName("advancedFields")
        form = QtWidgets.QFormLayout(fields)
        self.mode = QtWidgets.QComboBox()
        self.mode.addItem("Automatic · managed shared engine", "managed")
        self.mode.addItem("Existing ComfyUI installation", "existing")
        form.addRow("Engine:", self.mode)
        self.runtime_edit, runtime_row = self.path_row("Choose the engine folder")
        self.model_edit, model_row = self.path_row("Choose the model storage folder")
        self.python_edit, self.python_row = self.path_row(
            "Choose ComfyUI's Python executable", executable=True
        )
        self.python_label = QtWidgets.QLabel("Python executable:")
        form.addRow("Engine folder:", runtime_row)
        form.addRow("Model storage:", model_row)
        form.addRow(self.python_label, self.python_row)
        self.hardware = QtWidgets.QComboBox()
        self.hardware.addItem("Automatic", "auto")
        self.hardware.addItem("Older NVIDIA / low VRAM", "compatibility")
        self.hardware.addItem("CPU only · very slow", "cpu")
        form.addRow("Hardware:", self.hardware)
        self.width_spin, self.height_spin = QtWidgets.QSpinBox(), QtWidgets.QSpinBox()
        sizes = QtWidgets.QWidget()
        size_row = QtWidgets.QHBoxLayout(sizes)
        size_row.setContentsMargins(0, 0, 0, 0)
        for field in (self.width_spin, self.height_spin):
            field.setRange(256, 2048)
            field.setSingleStep(64)
        size_row.addWidget(self.width_spin)
        size_row.addWidget(QtWidgets.QLabel("×"))
        size_row.addWidget(self.height_spin)
        form.addRow("Image size:", sizes)
        self.steps = QtWidgets.QSpinBox()
        self.steps.setRange(1, 100)
        form.addRow("Sampling steps:", self.steps)
        self.enhance_check = QtWidgets.QCheckBox("Automatically improve prompts")
        form.addRow(self.enhance_check)
        self.helper_model_edit, helper_model_row = self.path_row("Choose the prompt model folder")
        self.helper_runtime_edit, helper_runtime_row = self.path_row(
            "Choose the folder containing llama-server.exe"
        )
        self.helper_model_edit.setPlaceholderText("Automatic · discover or download")
        self.helper_runtime_edit.setPlaceholderText("Automatic · discover or install")
        form.addRow("Prompt model folder:", helper_model_row)
        form.addRow("Prompt engine folder:", helper_runtime_row)
        self.cache_note = QtWidgets.QLabel(
            "Engine and model folders may be shared across applications. Removing an image model keeps shared prompt tools and engines. External files are never removed."
        )
        self.cache_note.setWordWrap(True)
        form.addRow(self.cache_note)
        self.advanced.setWidget(fields)
        detail.addWidget(self.advanced)
        detail.addStretch()
        body.addWidget(self.detail_panel, 2)
        layout.addLayout(body, 1)
        self.empty_label = QtWidgets.QLabel("No supported models are available in this catalog.")
        self.empty_label.setVisible(not self.catalog)
        layout.addWidget(self.empty_label)
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self.model_list.currentRowChanged.connect(self.select_model)
        self.primary_button.clicked.connect(self.primary_action)
        self.existing_button.clicked.connect(self.connect_existing)
        self.advanced_toggle.toggled.connect(self.toggle_advanced)
        self.mode.currentIndexChanged.connect(self.change_engine_mode)
        self.runtime_edit.editingFinished.connect(self.locate_existing)
        for field in (
            self.runtime_edit,
            self.model_edit,
            self.python_edit,
            self.helper_model_edit,
            self.helper_runtime_edit,
        ):
            field.textChanged.connect(self.refresh)
        for field in (self.width_spin, self.height_spin, self.steps):
            field.valueChanged.connect(self.refresh)
        self.hardware.currentIndexChanged.connect(self.refresh)
        self.license_check.toggled.connect(self.refresh)
        self.enhance_check.toggled.connect(self.refresh)
        self.enhancement_button.clicked.connect(self.add_enhancement)
        self.verify_action.triggered.connect(self.verify)
        self.remove_action.triggered.connect(self.remove)
        self.disconnect_action.triggered.connect(self.disconnect)
        selected = next((i for i, p in enumerate(self.catalog) if p.id == self.active_id), 0)
        self.model_list.setCurrentRow(selected if self.catalog else -1)
        self.detail_panel.setVisible(bool(self.catalog))

    def profile(self):
        return next(p for p in self.catalog if p.id == self.current_id)

    def path_row(self, title, executable=False):
        edit = QtWidgets.QLineEdit()
        button = QtWidgets.QPushButton("Browse…")
        row = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout(row)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(edit)
        layout.addWidget(button)

        def browse():
            value = (
                QtWidgets.QFileDialog.getOpenFileName(self, title, edit.text())[0]
                if executable
                else QtWidgets.QFileDialog.getExistingDirectory(self, title, edit.text())
            )
            if value:
                edit.setText(value)
                if edit is self.runtime_edit:
                    self.locate_existing()

        button.clicked.connect(browse)
        return edit, row

    def config(self):
        if self.current_id is None:
            raise ManagerError("Choose a model from the catalog first.")
        return LocalConfig.from_dict(
            self.drafts[self.current_id].to_dict()
            | {
                "runtime_root": self.runtime_edit.text().strip(),
                "model_root": self.model_edit.text().strip(),
                "python_executable": self.python_edit.text().strip(),
                "mode": self.mode.currentData(),
                "hardware": self.hardware.currentData(),
                "width": self.width_spin.value(),
                "height": self.height_spin.value(),
                "steps": self.steps.value(),
                "accepted_license": self.current_id if self.license_check.isChecked() else "",
                "enhance_prompts": self.enhance_check.isChecked(),
                "helper_model_root": self.helper_model_edit.text().strip(),
                "helper_runtime_root": self.helper_runtime_edit.text().strip(),
            }
        )

    def select_model(self, row):
        if self.current_id:
            try:
                self.drafts[self.current_id] = self.config()
            except ManagerError:
                pass
        if row < 0:
            return
        self.current_id = self.catalog[row].id
        self.load_config(self.drafts[self.current_id])

    def load_config(self, config):
        self.loading = True
        self.runtime_edit.setText(config.runtime_root)
        self.model_edit.setText(config.model_root)
        self.python_edit.setText(config.python_executable)
        self.mode.setCurrentIndex(self.mode.findData(config.mode))
        self.hardware.setCurrentIndex(self.hardware.findData(config.hardware))
        self.width_spin.setValue(config.width)
        self.height_spin.setValue(config.height)
        self.steps.setValue(config.steps)
        self.enhance_check.setChecked(config.enhance_prompts)
        self.helper_model_edit.setText(config.helper_model_root)
        self.helper_runtime_edit.setText(config.helper_runtime_root)
        self.license_check.setChecked(config.accepted_license == self.current_id)
        self.loading = False
        self.mode_changed()

    def toggle_advanced(self, opened):
        self.advanced.setVisible(opened)
        self.advanced_toggle.setArrowType(
            QtCore.Qt.ArrowType.DownArrow if opened else QtCore.Qt.ArrowType.RightArrow
        )
        self.resize(self.width(), 760 if opened else 460)

    def mode_changed(self):
        existing = self.mode.currentData() == "existing"
        self.python_row.setVisible(existing)
        self.python_label.setVisible(existing)
        self.disconnect_action.setVisible(existing)
        self.refresh()

    def change_engine_mode(self):
        if not self.loading and self.mode.currentData() == "managed":
            self.loading = True
            self.runtime_edit.setText(default_config().runtime_root)
            self.python_edit.clear()
            self.loading = False
        self.mode_changed()

    def locate_existing(self):
        if self.mode.currentData() != "existing":
            return
        try:
            self.adopt_folder(self.runtime_edit.text())
        except ManagerError:
            return

    def adopt_folder(self, folder):
        comfy, python, models = discover_installation(folder)
        self.loading = True
        self.mode.setCurrentIndex(self.mode.findData("existing"))
        self.runtime_edit.setText(str(comfy))
        self.python_edit.setText(str(python) if python else "")
        self.model_edit.setText(str(models))
        self.loading = False
        self.mode_changed()
        if not python:
            self.advanced_toggle.setChecked(True)

    def connect_existing(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Choose ComfyUI or its models folder"
        )
        if folder:
            try:
                self.adopt_folder(folder)
            except ManagerError as error:
                QtWidgets.QMessageBox.warning(self, "Existing installation", str(error))

    def is_verified(self, config, profile):
        return self.verified.get(profile.id) == connection_key(
            config, profile
        ) or self.library.verified(config, profile)

    def refresh(self):
        if self.loading or not self.current_id:
            return
        profile = self.profile()
        self.title_label.setText(profile.name)
        self.description.setText(profile.description)
        self.capabilities.setText(
            " · ".join(CAPABILITY_LABELS.get(c, c.replace("_", " ")) for c in profile.capabilities)
        )
        self.license_summary.setText(profile.license_summary)
        color = (
            self.palette_data.get("link_color", "#75B9EF")
            if self.palette_data
            else self.palette().color(self.foregroundRole()).name()
        )
        self.license_link.setText(
            f'<a style="color:{color}" href="{escape(profile.license_url, quote=True)}">Read {escape(profile.license_name)}</a>'
        )
        self.primary_button.setEnabled(False)
        self.remove_action.setEnabled(False)
        self.verify_action.setEnabled(False)
        self.action = None
        self.enhancement_button.hide()
        self.enhance_check.setEnabled(bool(profile.enhancement))
        try:
            config = self.config()
            check_support(profile)
            store = ModelStore(config.model_root, config.state_root)
            status, engine = store.status(profile), runtime_status(config)
            helpers = enhancement_status(config, profile) if profile.enhancement else "Ready"
            helpers_needed = bool(profile.enhancement and config.enhance_prompts)
            ready = status == "Ready" and engine == "Ready" and self.is_verified(config, profile)
            ready = ready and (not helpers_needed or helpers == "Ready")
            self.status_label.setText(
                (
                    "Selected for generation"
                    if ready and self.active_id == profile.id
                    else "Ready to use"
                )
                if ready
                else f"Model: {status}"
            )
            if ready:
                self.action, label = "use", "Use model"
                self.install_note.setText(
                    "Installed and verified. "
                    + (
                        "Automatic prompt enhancement is enabled."
                        if helpers_needed
                        else "Choosing Use model selects it for image generation."
                    )
                )
            elif (
                status in {"Ready", "Needs verification"}
                and engine == "Ready"
                and (not helpers_needed or helpers in {"Ready", "Needs verification"})
            ):
                self.action, label = "verify", "Verify model"
                self.install_note.setText(
                    "Model files were found. Verify this model and its engine before using it."
                )
            else:
                self.action, label = "install", (
                    "Resume installation" if status == "Incomplete" else "Install model"
                )
                remaining = store.remaining_bytes(profile)
                space = remaining + (RUNTIME_SPACE if engine != "Ready" else 0) + 2 * 1024**3
                if helpers_needed:
                    helper_bytes, helper_engine_bytes = enhancement_size(config, profile)
                    remaining += helper_bytes
                    space += helper_bytes + helper_engine_bytes
                engine_note = (
                    "Your compatible engine will be reused."
                    if engine == "Ready"
                    else "The required shared engine will be set up automatically. Windows x64 + NVIDIA GPU required for automatic setup."
                )
                if engine != "Ready" and config.hardware == "cpu":
                    engine_note = "The shared engine will be set up automatically. CPU generation is very slow."
                if config.mode == "existing" and engine != "Ready":
                    self.action, label = None, "Check engine location"
                    engine_note = "Check your existing engine's location under Advanced, or choose the automatic managed engine."
                self.install_note.setText(
                    f"{remaining / 1024**3:.1f} GiB of model files to download · allow about {space / 1024**3:.0f} GiB free.\n"
                    + ("Includes automatic prompt enhancement. " if helpers_needed else "")
                    + engine_note
                )
                if (
                    helpers_needed
                    and status in {"Ready", "Needs verification"}
                    and engine == "Ready"
                ):
                    label = "Complete prompt setup"
            self.primary_button.setText(label)
            self.primary_button.setEnabled(bool(self.action) and self.license_check.isChecked())
            self.remove_action.setEnabled(store.owns(profile))
            self.verify_action.setEnabled(
                status in {"Ready", "Needs verification"}
                and engine == "Ready"
                and (not helpers_needed or helpers in {"Ready", "Needs verification"})
            )
            if (
                profile.enhancement
                and not config.enhance_prompts
                and status in {"Ready", "Needs verification"}
            ):
                self.enhancement_button.show()
                self.enhancement_button.setEnabled(self.license_check.isChecked())
                missing, _ = enhancement_size(config, profile)
                self.enhancement_button.setText(
                    f"Add prompt enhancement · {missing / 1024**3:.1f} GiB"
                    if missing
                    else "Enable prompt enhancement"
                )
        except (ManagerError, OSError) as error:
            self.status_label.setText(str(error))
            self.install_note.clear()
        self.update_catalog_status()

    def update_catalog_status(self):
        for row, profile in enumerate(self.catalog):
            try:
                config = self.config() if profile.id == self.current_id else self.drafts[profile.id]
                status = ModelStore(config.model_root, config.state_root).status(profile)
                if status == "Ready":
                    status = "Installed"
                    if profile.enhancement:
                        if config.enhance_prompts:
                            status = (
                                "Installed"
                                if enhancement_status(config, profile) == "Ready"
                                else "Prompt setup needed"
                            )
                        else:
                            status = "Installed · Image only"
                if profile.id == self.active_id:
                    status += " · Selected"
            except (ManagerError, OSError):
                status = "Needs attention"
            self.model_list.item(row).setText(f"{profile.name}\n{status}")

    def primary_action(self):
        if not self.primary_button.isEnabled():
            return
        if self.action == "use":
            self.use_model()
        elif self.action == "verify":
            self.verify()
        elif self.action == "install":
            self.install()

    def _perform(self, task, title):
        try:
            config, profile = self.config(), self.profile()
            if config.accepted_license != profile.id:
                raise ManagerError(
                    "Review this model's license and confirm your use is permitted before continuing."
                )
            self.verified.pop(profile.id, None)
            self.library.remember(config, profile, verified=False)
            run_task(
                self,
                title,
                lambda progress, cancel: task(config, progress, cancel),
                self.palette_data,
            )
            self.library.remember(config, profile, verified=True)
            self.verified[profile.id] = connection_key(config, profile)
            self.drafts[profile.id] = config
            self.load_config(config)
        except Cancelled:
            pass
        except Exception as error:
            QtWidgets.QMessageBox.warning(self, title, str(error))
        self.refresh()

    def install(self):
        self._perform(install_model, f"Installing {self.profile().name}")

    def verify(self):
        self._perform(verify_model, f"Verifying {self.profile().name}")

    def add_enhancement(self):
        self._perform(install_prompt_tools, "Setting up prompt enhancement")

    def use_model(self):
        self.refresh()
        if self.action == "use" and self.primary_button.isEnabled():
            config = self.config()
            try:
                self.library.remember(config, self.profile(), verified=True)
            except OSError as error:
                QtWidgets.QMessageBox.warning(self, "Select model", str(error))
                return
            self.selected_config = config.to_dict()
            self.accept()

    def remove(self):
        config, profile = self.config(), self.profile()
        if (
            QtWidgets.QMessageBox.question(
                self,
                "Remove model",
                f"Remove the image files for {profile.name}? This affects all applications sharing this cache. Shared prompt tools, engines, other models, and externally installed files are kept.",
            )
            == QtWidgets.QMessageBox.StandardButton.Yes
        ):
            try:
                ModelStore(config.model_root, config.state_root).remove(profile)
                ComponentStore(config).release_recipe(profile)
                self.library.remember(config, profile, verified=False)
                self.verified.pop(profile.id, None)
            except Exception as error:
                QtWidgets.QMessageBox.warning(self, "Remove model", str(error))
            self.refresh()

    def disconnect(self):
        profile = self.profile()
        self.library.forget(profile.id)
        self.verified.pop(profile.id, None)
        self.drafts[profile.id] = replace(
            default_config(),
            model_id=profile.id,
            state_root=self.initial.state_root,
            width=profile.default_width,
            height=profile.default_height,
            steps=profile.default_steps,
        )
        self.load_config(self.drafts[profile.id])
        if self.active_id == profile.id:
            self.selected_config = self.config().to_dict()
            self.accept()
