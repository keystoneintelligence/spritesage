"""One local prompt rewrite per process; no prompt or reasoning history."""

import base64
import ctypes
import io
import json
import math
import os
import queue
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from importlib.resources import files
from typing import Callable

from PIL import Image

from . import prompt_runtime
from .catalog import get_profile
from .components import ComponentStore
from .runtime import clean_environment, spawn, stop_process
from .types import Cancelled, ManagerError, Progress, check_cancel, emit

MAX_TOKENS = {"t2i": 16256, "edit": 24000}


def available_memory():
    if sys.platform != "win32":
        return None

    class MemoryStatus(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [
            (name, ctypes.c_ulonglong)
            for name in (
                "total",
                "available",
                "page_total",
                "page_available",
                "virtual_total",
                "virtual_available",
                "extended",
            )
        ]

    status = MemoryStatus()
    status.length = ctypes.sizeof(status)
    return (
        status.available
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
        else None
    )


class EnhancementError(ManagerError):
    """A rewrite failed; the host may offer an explicit retry without rewriting."""

    generate_original: Callable[..., str] | None = None


def parse_rewrite(text, reference_count):
    if "</think>" not in text:
        raise EnhancementError(
            "Prompt enhancement did not complete its answer. Retry or generate with the original prompt."
        )
    answer = text.split("</think>", 1)[1]
    decoder = json.JSONDecoder()
    candidates, offset = [], 0
    while offset < len(answer):
        start = answer.find("{", offset)
        if start < 0:
            break
        try:
            value, consumed = decoder.raw_decode(answer[start:])
            offset = start + consumed
        except ValueError:
            offset = start + 1
            continue
        if isinstance(value, dict):
            prompt = value.get("rewritten_prompt") or value.get("rewrited_prompt")
            if isinstance(prompt, str) and prompt.strip():
                candidates.append(prompt.strip())
    if not candidates or len(candidates[-1]) > 16000:
        raise EnhancementError(
            "Prompt enhancement returned no complete usable answer. Retry or use the original prompt."
        )
    prompt = candidates[-1]
    indices = {int(number) for number in re.findall(r"<image(\d+)>", prompt)}
    if any(index < 1 or index > reference_count for index in indices):
        raise EnhancementError(
            "Prompt enhancement referred to an unknown reference image. Retry or use the original prompt."
        )
    if reference_count > 1 and indices != set(range(1, reference_count + 1)):
        raise EnhancementError(
            "Prompt enhancement omitted a reference image. Retry or use the original prompt."
        )
    return prompt


def messages_for(config, prompt, references, constraints=()):
    task = "edit" if references else "t2i"
    system = (
        files("modelmanager")
        .joinpath(f"data/system_prompt_{task}.txt")
        .read_text(encoding="utf-8")
        .strip()
    )
    # ComfyUI editing currently follows the first reference's proportions.
    width, height = config.width, config.height
    if references:
        with Image.open(references[0]) as image:
            width, height = image.size
    divisor = math.gcd(width, height)
    fixed = [
        f"The output canvas aspect ratio is fixed at {width // divisor}:{height // divisor}.",
        *constraints,
    ]
    system += (
        "\n\nApplication constraints take precedence over general elaboration guidance. Preserve all of them; do not invent scenery, lettering, panels, or extra subjects unless requested.\n"
        + "\n".join(fixed)
    )
    content = []
    for index, path in enumerate(references, 1):
        with Image.open(path) as source:
            # Composite transparency for vision; retain original RGBA references for ComfyUI.
            rgba = source.convert("RGBA")
            background = Image.new("RGBA", rgba.size, 0xFFFFFFFF)
            image = Image.alpha_composite(background, rgba).convert("RGB")
            if image.width * image.height > 1024**2:
                scale = math.sqrt(1024**2 / (image.width * image.height))
                image = image.resize(
                    (max(1, int(image.width * scale)), max(1, int(image.height * scale))),
                    Image.Resampling.LANCZOS,
                )
            image.info.clear()
            with io.BytesIO() as buffer:
                image.save(buffer, format="PNG")
                content.append({"type": "text", "text": f"<image{index}>"})
                content.append(
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": "data:image/png;base64,"
                            + base64.b64encode(buffer.getvalue()).decode("ascii")
                        },
                    }
                )
    content.append({"type": "text", "text": prompt})
    return task, [{"role": "system", "content": system}, {"role": "user", "content": content}]


class PromptEngine:
    def __init__(self, config, progress=None, cancel=None):
        self.config, self.progress, self.cancel = config, progress, cancel
        self.process = None
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.key, self.alias = secrets.token_urlsafe(32), secrets.token_hex(16)

    def request(self, route, payload=None, timeout=10):
        data = json.dumps(payload).encode() if payload is not None else None
        request = urllib.request.Request(
            self.url + route,
            data=data,
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + self.key},
        )
        return self.opener.open(request, timeout=timeout)

    def start(self, task, context=32768):
        check_cancel(self.cancel)
        profile = get_profile(self.config.model_id)
        spec = profile.enhancement
        if spec is None:
            raise ManagerError("This model has no prompt enhancement recipe.")
        component = spec.editing if task == "edit" else spec.creation
        memory = available_memory()
        if memory is not None and memory < 4 * 1024**3 + sum(f.size for f in component.files):
            raise EnhancementError(
                "There is not enough available memory for prompt improvement. Close other applications or generate with the original prompt."
            )
        located = ComponentStore(self.config).locate(component)
        root = prompt_runtime.locate(self.config)
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        self.url = f"http://127.0.0.1:{port}"
        threads = str(min(8, os.cpu_count() or 4))
        args = [
            root / "llama-server.exe",
            "--model",
            located[component.files[0].path],
            "--alias",
            self.alias,
            "--host",
            "127.0.0.1",
            "--port",
            str(port),
            "--ctx-size",
            str(context),
            "--parallel",
            "1",
            "--threads",
            threads,
            "--threads-batch",
            threads,
            "--batch-size",
            "256",
            "--ubatch-size",
            "128",
            "--flash-attn",
            "on",
            "--fit",
            "on",
            "--fit-target",
            "1024",
            "--cache-type-k",
            "f16",
            "--cache-type-v",
            "f16",
            "--jinja",
            "--reasoning",
            "on",
            "--reasoning-budget",
            "-1",
            "--reasoning-format",
            "none",
            "--no-context-shift",
            "--cache-ram",
            "0",
            "--ctx-checkpoints",
            "0",
            "--no-cache-idle-slots",
            "--no-webui",
            "--no-slots",
            "--log-disable",
            "--offline",
        ]
        if task == "edit":
            args += [
                "--mmproj",
                located[component.files[1].path],
                "--no-mmproj-offload",
                "--image-max-tokens",
                "1024",
            ]
        else:
            args += ["--no-mmproj"]
        if self.config.hardware == "cpu":
            args += ["--n-gpu-layers", "0", "--device", "none"]
        env = {k: v for k, v in clean_environment().items() if not k.startswith("LLAMA_")}
        env.update(LLAMA_API_KEY=self.key, GGML_CUDA_FORCE_MMQ="1")
        self.process = spawn(
            args,
            cwd=root,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        started = time.monotonic()
        while time.monotonic() - started < 180:
            check_cancel(self.cancel)
            if self.process.poll() is not None:
                raise EnhancementError(
                    "The prompt engine could not start. Close other GPU applications and retry."
                )
            try:
                with self.request("/v1/models", timeout=2) as response:
                    body = json.load(response)
                if not any(m.get("id") == self.alias for m in body.get("data", [])):
                    raise EnhancementError(
                        "The prompt engine port is occupied by another application."
                    )
                return
            except (urllib.error.URLError, TimeoutError, OSError):
                if self.cancel:
                    self.cancel.wait(0.5)
                else:
                    time.sleep(0.5)
        raise EnhancementError("The prompt engine took too long to load.")

    def stop(self):
        if self.process is not None:
            stop_process(self.process)
            self.process = None

    def rewrite(self, prompt, references, constraints=()):
        task, messages = messages_for(self.config, prompt, references, constraints)
        seed = self.config.seed if self.config.seed >= 0 else secrets.randbelow(2**32)
        body = {
            "messages": messages,
            "stream": True,
            "stream_options": {"include_usage": True},
            "temperature": 1.0,
            "top_k": 20,
            "top_p": 0.95,
            "min_p": 0.0,
            "repeat_penalty": 1.0,
            "presence_penalty": 1.5 if task == "t2i" else 0.0,
            "frequency_penalty": 0.0,
            "repeat_last_n": 32768,
            "max_tokens": MAX_TOKENS[task],
            "seed": seed % (2**32),
            "chat_template_kwargs": {"enable_thinking": True},
            "reasoning_format": "none",
            "reasoning_budget": -1,
            "cache_prompt": False,
            "timings_per_token": True,
        }
        started = time.monotonic()
        fragments, reader, response = [], None, None
        try:
            emit(self.progress, "Improving prompt · loading local prompt engine…")
            self.start(task)
            text = messages[0]["content"] + "\n" + prompt
            with self.request(
                "/tokenize", {"content": text, "add_special": False, "parse_special": True}
            ) as token_response:
                count = len(json.load(token_response)["tokens"])
            required = count + 256 + 1152 * len(references) + MAX_TOKENS[task]
            if required > 65536:
                raise EnhancementError(
                    "This prompt and its references exceed the supported context. Shorten the prompt or use fewer references."
                )
            if required > 32768:
                self.stop()
                self.start(task, math.ceil(required / 8192) * 8192)
            events = queue.Queue(maxsize=128)
            stopped = threading.Event()

            def read_stream():
                nonlocal response

                def publish(value):
                    while not stopped.is_set():
                        try:
                            events.put(value, timeout=0.2)
                            return
                        except queue.Full:
                            pass

                try:
                    response = self.request("/v1/chat/completions", body, timeout=120)
                    for line in response:
                        publish(line)
                        if stopped.is_set():
                            return
                except Exception as error:
                    publish(error)
                finally:
                    publish(None)

            reader = threading.Thread(target=read_stream, daemon=True)
            reader.start()
            finish, last, length = None, 0, 0
            while True:
                check_cancel(self.cancel)
                elapsed = int(time.monotonic() - started)
                if elapsed > 7200:
                    raise EnhancementError("Prompt enhancement exceeded two hours and was stopped.")
                if self.process is None or self.process.poll() is not None:
                    raise EnhancementError("The prompt engine stopped unexpectedly.")
                if elapsed - last >= 2:
                    memory = available_memory()
                    if memory is not None and memory < 4 * 1024**3:
                        raise EnhancementError(
                            "Prompt improvement stopped to keep 4 GiB of system memory free. Close other applications and retry."
                        )
                    emit(
                        self.progress,
                        f"Improving prompt · {elapsed // 60}m {elapsed % 60}s elapsed",
                    )
                    last = elapsed
                try:
                    line = events.get(timeout=0.2)
                except queue.Empty:
                    continue
                if line is None:
                    break
                if isinstance(line, Exception):
                    raise EnhancementError(
                        "The prompt engine connection was interrupted."
                    ) from line
                if not line.startswith(b"data: "):
                    continue
                value = line[6:].strip()
                if value == b"[DONE]":
                    break
                event = json.loads(value)
                if "error" in event:
                    raise EnhancementError("The prompt engine could not complete the request.")
                for choice in event.get("choices", []):
                    piece = choice.get("delta", {}).get("content")
                    if piece:
                        length += len(piece)
                        if length > 512000:
                            raise EnhancementError(
                                "The prompt engine returned an oversized answer."
                            )
                        fragments.append(piece)
                    finish = choice.get("finish_reason") or finish
            if finish != "stop":
                raise EnhancementError(
                    "Prompt enhancement did not complete its full answer. Retry or use the original prompt."
                )
            rewritten = parse_rewrite("".join(fragments), len(references))
            if self.progress:
                self.progress(
                    Progress(
                        "Prompt improved",
                        detail=f"Prompt enhancement finished in {time.monotonic() - started:.1f}s ({task}).",
                    )
                )
            return rewritten
        except Cancelled:
            raise
        except EnhancementError:
            raise
        except Exception as error:
            raise EnhancementError(
                "Prompt enhancement failed. Retry or generate with the original prompt."
            ) from error
        finally:
            if reader is not None:
                stopped.set()
            self.stop()
            if reader is not None:
                reader.join(timeout=5)
            if response is not None:
                response.close()
            fragments.clear()
            messages.clear()
            body.clear()
