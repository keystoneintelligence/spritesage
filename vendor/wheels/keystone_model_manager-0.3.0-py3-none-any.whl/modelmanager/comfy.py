"""Private ComfyUI worker processes and a curated image workflow."""

import json
import secrets
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path

from filelock import FileLock, Timeout

from .catalog import get_profile
from .config import LocalConfig, runtime_paths
from .runtime import clean_environment, runtime_status, spawn, stop_process
from .storage import ModelStore
from .types import ManagerError, check_cancel, emit


def hardware_flags(config: LocalConfig):
    selected = config.hardware
    if selected == "auto":
        try:
            with spawn(
                ["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
            ) as process:
                value, _ = process.communicate(timeout=10)
                if process.returncode == 0 and float(value.splitlines()[0]) < 8:
                    selected = "compatibility"
        except (OSError, ValueError, IndexError, subprocess.TimeoutExpired):
            selected = "auto"
    if selected == "cpu":
        return ["--cpu", "--force-fp32", "--fp32-vae"]
    flags = ["--lowvram", "--reserve-vram", "1"]
    if selected == "compatibility":
        flags += [
            "--force-fp32",
            "--fp32-text-enc",
            "--fp32-vae",
            "--cpu-vae",
            "--use-split-cross-attention",
            "--disable-dynamic-vram",
            "--disable-pinned-memory",
            "--disable-comfy-compiler",
        ]
    return flags


def _qwen_image_21(config: LocalConfig, prompt: str, references: list[str]):
    profile = get_profile(config.model_id)
    if len(references) > profile.max_references:
        raise ManagerError(
            f"This model supports at most {profile.max_references} reference images."
        )
    model_names = {Path(item.path).parent.name: Path(item.path).name for item in profile.files}
    seed = config.seed if config.seed >= 0 else secrets.randbelow(2**63)
    graph = {}

    def node(key, kind, **inputs):
        graph[str(key)] = {"class_type": kind, "inputs": inputs}

    node(1, "UNETLoader", unet_name=model_names["diffusion_models"], weight_dtype="default")
    node(2, "CLIPLoader", clip_name=model_names["text_encoders"], type="qwen_image", device="cpu")
    node(3, "VAELoader", vae_name=model_names["vae"])
    encode = {
        "clip": ["2", 0],
        "prompt": prompt,
        "negative_prompt": "",
        "resolution": max(config.width, config.height),
    }
    if references:
        encode["vae"] = ["3", 0]
    for index, name in enumerate(references):
        load, join = 20 + index * 2, 21 + index * 2
        node(load, "LoadImage", image=name)
        node(join, "JoinImageWithAlpha", image=[str(load), 0], alpha=[str(load), 1])
        encode[f"images.image_{index + 1}"] = [str(join), 0]
    node(4, "TextEncodeQwenImage21", **encode)
    node(5, "QwenImage21Cache", model=["1", 0], device="cpu", dtype="default")
    node(6, "EmptyLatentImage", width=config.width, height=config.height, batch_size=1)
    node(
        7,
        "KSampler",
        model=["5", 0],
        positive=["4", 0],
        negative=["4", 1],
        latent_image=["4", 2] if references else ["6", 0],
        seed=seed,
        steps=config.steps,
        cfg=1.0,
        sampler_name="euler",
        scheduler="simple",
        denoise=1.0,
    )
    if max(config.width, config.height) <= 1024:
        node(8, "VAEDecode", samples=["7", 0], vae=["3", 0])
    else:
        node(
            8,
            "VAEDecodeTiled",
            samples=["7", 0],
            vae=["3", 0],
            tile_size=512,
            overlap=128,
            temporal_size=64,
            temporal_overlap=8,
        )
    node(9, "SaveImage", images=["8", 0], filename_prefix="result")
    return graph


# Every catalog entry names a tested builder. New families must register their own.
# Builders return a ComfyUI graph with the final SaveImage output at node "9".
WORKFLOWS = {"qwen_image_21": _qwen_image_21}


def build_workflow(config: LocalConfig, prompt: str, references: list[str]):
    profile = get_profile(config.model_id)
    if len(references) > profile.max_references:
        raise ManagerError(
            f"This model supports at most {profile.max_references} reference images."
        )
    if references and "image_edit" not in profile.capabilities:
        raise ManagerError(
            "This model does not support reference-based editing. Choose a model with image editing support."
        )
    try:
        builder = WORKFLOWS[profile.workflow]
    except KeyError as error:
        raise ManagerError(
            "This model's generation workflow is not supported by this version."
        ) from error
    return builder(config, prompt, references)


class ComfyEngine:
    def __init__(self, config: LocalConfig, progress=None, cancel=None, *, cache_lease=None):
        self.config = config
        self.progress = progress
        self.cancel = cancel
        self.process = None
        self.log = None
        self.folder = None
        self.lock = None
        self.cache_lock = None
        self.cache_lease = cache_lease
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def request(self, route: str, payload=None, *, binary=False):
        check_cancel(self.cancel)
        data = json.dumps(payload).encode() if payload is not None else None
        request = urllib.request.Request(
            self.url + route, data=data, headers={"Content-Type": "application/json"}
        )
        try:
            with self.opener.open(request, timeout=10) as response:
                raw = response.read(128 * 1024**2)
            return raw if binary else json.loads(raw)
        except urllib.error.HTTPError as error:
            detail = error.read(4096).decode("utf-8", errors="replace")
            raise ManagerError(f"ComfyUI rejected the request ({error.code}): {detail}") from error

    def __enter__(self):
        try:
            self.start()
            return self
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def start(self):
        self.config.validate()
        from .installation import check_support

        check_support(get_profile(self.config.model_id))
        if runtime_status(self.config) != "Ready":
            raise ManagerError(
                "Local generation is not set up. Open Manage local models to install or verify it."
            )
        store = ModelStore(self.config.model_root, self.config.state_root)
        profile = get_profile(self.config.model_id)
        if store.owns(profile) and self.cache_lease is None:
            self.cache_lock = FileLock(str(store.root / ".modelmanager-download.lock"), timeout=0)
            try:
                self.cache_lock.acquire()
            except Timeout as error:
                self.cache_lock = None
                raise ManagerError(
                    "This model cache is being used by another job or installation."
                ) from error
        if store.status(profile) != "Ready":
            raise ManagerError(
                "Local model files need verification. Open Manage local models and choose Verify setup."
            )
        state = Path(self.config.state_root)
        state.mkdir(parents=True, exist_ok=True)
        self.lock = FileLock(str(state / "inference.lock"), timeout=0)
        try:
            self.lock.acquire()
        except Timeout as error:
            self.lock = None
            raise ManagerError(
                "Another local generation job is running. Wait for it to finish and retry."
            ) from error
        jobs = state / "jobs"
        jobs.mkdir(exist_ok=True)
        self.folder = Path(tempfile.mkdtemp(prefix="job-", dir=jobs))
        for name in ("input", "output", "temp", "user"):
            (self.folder / name).mkdir()
        model_paths = {"is_default": True}
        for relative, path in store.locate(profile).items():
            model_paths[Path(relative).parent.name] = str(path.parent.resolve())
        paths_file = self.folder / "models.yaml"
        paths_file.write_text(json.dumps({"modelmanager": model_paths}), encoding="utf-8")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        self.url = f"http://127.0.0.1:{port}"
        comfy, python = runtime_paths(self.config)
        args = [
            python,
            comfy / "main.py",
            "--listen",
            "127.0.0.1",
            "--port",
            str(port),
            "--disable-auto-launch",
            "--disable-api-nodes",
            "--disable-all-custom-nodes",
            "--disable-metadata",
            "--cache-none",
            "--preview-method",
            "none",
            "--database-url",
            "sqlite:///:memory:",
            "--extra-model-paths-config",
            paths_file,
        ]
        for name in ("input", "output", "temp", "user"):
            args += [f"--{name}-directory", self.folder / name]
        args += hardware_flags(self.config)
        env = clean_environment()
        env.update(
            HF_HUB_OFFLINE="1",
            HF_HUB_DISABLE_TELEMETRY="1",
            OMP_NUM_THREADS="8",
            MKL_NUM_THREADS="8",
            TEMP=str(self.folder / "temp"),
            TMP=str(self.folder / "temp"),
        )
        log_dir = state / "logs"
        log_dir.mkdir(exist_ok=True)
        self.log_path = log_dir / "last-engine.log"
        self.log = self.log_path.open("w", encoding="utf-8")
        emit(self.progress, "Starting local image engine…")
        self.process = spawn(args, cwd=comfy, env=env, stdout=self.log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            check_cancel(self.cancel)
            if self.process.poll() is not None:
                raise ManagerError(f"Local engine could not start. Check {self.log_path}.")
            try:
                self.request("/system_stats")
                break
            except (OSError, urllib.error.URLError):
                if self.cancel:
                    self.cancel.wait(0.25)
                else:
                    time.sleep(0.25)
        else:
            raise ManagerError(
                f"Local engine did not start within 3 minutes. Check {self.log_path}."
            )
        self.validate_nodes()

    def validate_nodes(self):
        schema = self.request("/object_info")
        profile = get_profile(self.config.model_id)
        graph = build_workflow(
            self.config,
            "connection check",
            ["example.png"] if "image_edit" in profile.capabilities else [],
        )
        missing = sorted({node["class_type"] for node in graph.values()} - schema.keys())
        if missing:
            raise ManagerError(
                "This ComfyUI version is missing required nodes: "
                + ", ".join(missing)
                + ". Choose Install local generation for a compatible managed runtime."
            )
        filenames = {Path(item.path).name for item in profile.files}
        for node in graph.values():
            required = schema[node["class_type"]].get("input", {}).get("required", {})
            for name, value in node["inputs"].items():
                definition = required.get(name, [])
                if (
                    isinstance(value, str)
                    and value in filenames
                    and definition
                    and isinstance(definition[0], list)
                    and value not in definition[0]
                ):
                    raise ManagerError(
                        f"The engine cannot locate {value}. Check the configured model folder."
                    )
        emit(self.progress, "Local engine and model connection verified", 1, 1)

    def generate(self, prompt: str, references: list[str], output_folder: str | Path) -> str:
        from PIL import Image

        if not prompt.strip():
            raise ManagerError("Enter a description before generating an image.")
        copied = []
        for index, source in enumerate(references):
            check_cancel(self.cancel)
            path = self.folder / "input" / f"reference-{index}.png"
            try:
                with Image.open(source) as image:
                    image.convert("RGBA").save(path)
            except (OSError, ValueError) as error:
                raise ManagerError(f"Could not read reference image {source}.") from error
            copied.append(path.name)
        workflow = build_workflow(self.config, prompt, copied)
        response = self.request("/prompt", {"prompt": workflow, "client_id": uuid.uuid4().hex})
        prompt_id = response.get("prompt_id")
        if not prompt_id or response.get("node_errors"):
            raise ManagerError(
                "The local image workflow was rejected: "
                + str(response.get("node_errors", response))
            )
        emit(
            self.progress,
            "Generating locally. Model loading and sampling may take several minutes…",
        )
        start = time.monotonic()
        last_progress = 0
        while time.monotonic() - start < 7200:
            check_cancel(self.cancel)
            if self.process.poll() is not None:
                raise ManagerError(
                    f"Local engine stopped. Check {self.log_path}; try a smaller image or fewer references."
                )
            record = self.request("/history/" + urllib.parse.quote(prompt_id)).get(prompt_id)
            if record:
                status = record.get("status", {})
                if status.get("status_str") == "error":
                    errors = [
                        data.get("exception_message", "Generation failed")
                        for kind, data in status.get("messages", [])
                        if kind == "execution_error"
                    ]
                    raise ManagerError(
                        "Local generation failed: " + "; ".join(errors or ["See the engine log."])
                    )
                output = record.get("outputs", {}).get("9", {}).get("images", [])
                if not output:
                    raise ManagerError("The local workflow finished without an image.")
                image = output[0]
                query = urllib.parse.urlencode(
                    {
                        "filename": image["filename"],
                        "subfolder": image.get("subfolder", ""),
                        "type": "output",
                    }
                )
                raw = self.request("/view?" + query, binary=True)
                from io import BytesIO

                with Image.open(BytesIO(raw)) as result:
                    result.verify()
                destination = Path(output_folder)
                destination.mkdir(parents=True, exist_ok=True)
                target = destination / f"local_sprite_{uuid.uuid4().hex}.png"
                target.write_bytes(raw)
                emit(self.progress, "Local image complete", 1, 1)
                return str(target)
            elapsed = int(time.monotonic() - start)
            if elapsed - last_progress >= 5:
                emit(
                    self.progress, f"Generating locally · {elapsed // 60}m {elapsed % 60}s elapsed"
                )
                last_progress = elapsed
            if self.cancel:
                self.cancel.wait(0.75)
            else:
                time.sleep(0.75)
        raise ManagerError("Local generation exceeded two hours and was stopped.")

    def __exit__(self, *_):
        try:
            if self.process:
                stop_process(self.process)
        finally:
            try:
                if self.log:
                    self.log.close()
                if self.folder:
                    jobs = (Path(self.config.state_root) / "jobs").resolve()
                    if self.folder.resolve().parent == jobs and self.folder.name.startswith("job-"):
                        shutil.rmtree(self.folder)
            finally:
                if self.lock:
                    self.lock.release()
                if self.cache_lock:
                    self.cache_lock.release()


def verify_connection(config: LocalConfig, progress=None, cancel=None):
    store = ModelStore(config.model_root, config.state_root)
    store.verify(get_profile(config.model_id), progress, cancel)
    with ComfyEngine(config, progress, cancel):
        pass


def generate_image(
    config: LocalConfig,
    prompt: str,
    references: list[str],
    output_folder,
    progress=None,
    cancel=None,
):
    with ComfyEngine(config, progress, cancel) as engine:
        return engine.generate(prompt, references, output_folder)
