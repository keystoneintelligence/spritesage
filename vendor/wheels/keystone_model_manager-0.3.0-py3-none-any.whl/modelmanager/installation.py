"""Install one chosen model, provisioning its compatible runtime only when missing."""

import os
import platform
import subprocess
import sys
from pathlib import Path

from .catalog import get_profile
from .comfy import verify_connection, WORKFLOWS
from .runtime import install_runtime, runtime_status, spawn
from .storage import ModelStore, require_space
from .types import ManagerError, Progress, check_cancel, emit
from .components import ComponentStore, component_bytes, component_status
from . import prompt_runtime

RUNTIME_SPACE = 10 * 1024**3
SUPPORTED_RUNTIME = "comfy-image-v1"


def check_support(profile):
    if profile.runtime != SUPPORTED_RUNTIME or profile.workflow not in WORKFLOWS:
        raise ManagerError(
            "This model needs an engine or workflow not included in this version of Model Manager."
        )
    if profile.enhancement and profile.enhancement.runtime != prompt_runtime.RUNTIME_ID:
        raise ManagerError(
            "This model's prompt engine is not included in this version of Model Manager."
        )


def enhancement_status(config, profile):
    if not profile.enhancement:
        return "Ready"
    model, engine = component_status(config, profile), prompt_runtime.status(config)
    if model == engine == "Ready":
        return "Ready"
    if model in {"Ready", "Needs verification"} and engine in {"Ready", "Needs verification"}:
        return "Needs verification"
    return "Incomplete"


def enhancement_size(config, profile):
    return component_bytes(config, profile), prompt_runtime.space_bytes(config)


def check_recipe_space(config, core_bytes, core_runtime_bytes, profile):
    if not (config.enhance_prompts and profile.enhancement):
        return check_install_space(config, core_bytes, core_runtime_bytes)
    entries = [
        (Path(config.model_root), core_bytes),
        (Path(config.runtime_root), core_runtime_bytes),
        (ComponentStore(config).root, component_bytes(config, profile)),
        (prompt_runtime.managed_root(config), prompt_runtime.space_bytes(config)),
    ]
    volumes = {}
    for path, size in entries:
        volume = _volume(path)
        old = volumes.get(volume, (path, 0))
        volumes[volume] = (old[0], old[1] + size)
    for path, size in volumes.values():
        if size:
            require_space(path, size)


def verify_prompt_tools(config, profile, progress=None, cancel=None):
    if not (config.enhance_prompts and profile.enhancement):
        return
    prompt_runtime.verify_prompts()
    store = ComponentStore(config)
    for component in profile.enhancement.components:
        store.verify(component, _phase(progress, "Verifying prompt enhancement…"), cancel)
    prompt_runtime.verify(config, _phase(progress, "Checking prompt engine…"), cancel)
    store.remember_recipe(profile)


def install_prompt_tools(config, progress=None, cancel=None):
    """Add a model's helpers without changing its active selection or image files."""
    from dataclasses import replace

    profile = get_profile(config.model_id)
    check_support(profile)
    if not profile.enhancement:
        return
    if config.accepted_license != profile.id:
        raise ManagerError("Review this model's license before installing its prompt tools.")
    check_cancel(cancel)
    chosen = replace(config, enhance_prompts=True)
    check_recipe_space(chosen, 0, 0, profile)
    store = ComponentStore(chosen)
    for component in profile.enhancement.components:
        if store.status(component) != "Ready":
            store.install(component, _phase(progress, "Installing prompt enhancement…"), cancel)
    prompt_runtime.install(chosen, _phase(progress, "Setting up the prompt engine…"), cancel)
    prompt_runtime.verify_prompts()
    store.remember_recipe(profile)
    # Do not change the saved setting on failure or cancellation.
    config.enhance_prompts = True
    emit(progress, "Prompt enhancement is ready", 1, 1)


def _volume(path):
    path = Path(path).resolve()
    while not path.exists():
        path = path.parent
    return os.stat(path).st_dev


def check_install_space(config, model_bytes, runtime_bytes):
    model_root, runtime_root = Path(config.model_root), Path(config.runtime_root)
    if _volume(model_root) == _volume(runtime_root):
        require_space(model_root, model_bytes + runtime_bytes)
    else:
        require_space(model_root, model_bytes)
        if runtime_bytes:
            require_space(runtime_root, runtime_bytes)


def check_hardware(config):
    if sys.platform != "win32" or platform.machine().lower() not in {"amd64", "x86_64"}:
        raise ManagerError(
            "Automatic engine setup currently supports Windows x64. Connect an existing installation instead."
        )
    if config.hardware == "cpu":
        return
    try:
        with spawn(
            ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        ) as process:
            try:
                output, _ = process.communicate(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.communicate()
                raise ManagerError(
                    "GPU detection timed out. Check the NVIDIA driver before installing."
                )
            if process.returncode or not output.strip():
                raise OSError("No NVIDIA GPU detected")
    except OSError as error:
        raise ManagerError(
            "No available NVIDIA GPU was found. Check its driver, connect an existing engine, or choose CPU mode under Advanced (very slow)."
        ) from error


def _phase(callback, message):
    def progress(update):
        if callback:
            callback(Progress(message, update.completed, update.total, update.message))

    return progress


def install_model(config, progress=None, cancel=None):
    config.validate()
    profile = get_profile(config.model_id)
    check_support(profile)
    if config.accepted_license != profile.id:
        raise ManagerError("Review this model's license before installing it.")
    check_cancel(cancel)
    store = ModelStore(config.model_root, config.state_root)
    needs_runtime = runtime_status(config) != "Ready"
    if config.mode == "existing" and needs_runtime:
        raise ManagerError(
            "The selected existing engine is not ready. Check its location under Advanced, or choose the managed engine."
        )
    emit(progress, "Checking installation requirements…")
    if needs_runtime:
        check_hardware(config)
    check_recipe_space(
        config, store.remaining_bytes(profile), RUNTIME_SPACE if needs_runtime else 0, profile
    )
    if needs_runtime:
        install_runtime(config, _phase(progress, "Setting up the shared image engine…"), cancel)
    else:
        emit(progress, "Using your existing image engine")
    check_cancel(cancel)
    if store.status(profile) != "Ready":
        store.install(profile, _phase(progress, f"Installing {profile.name}…"), cancel)
    if config.enhance_prompts and profile.enhancement:
        install_prompt_tools(config, progress, cancel)
    verify_model(config, progress, cancel)


def verify_model(config, progress=None, cancel=None):
    profile = get_profile(config.model_id)
    check_support(profile)
    verify_connection(config, _phase(progress, f"Checking {profile.name}…"), cancel)
    verify_prompt_tools(config, profile, progress, cancel)
    emit(progress, f"{profile.name} is ready", 1, 1)
