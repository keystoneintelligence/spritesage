"""Remember independent model configurations without changing a host's active model."""

from dataclasses import replace
from pathlib import Path

from filelock import FileLock

from .config import LocalConfig
from .storage import atomic_json, read_json
from .types import ManagerError
from dataclasses import asdict
import hashlib
import json


def connection_key(config: LocalConfig, profile):
    values = config.to_dict()
    return {
        key: values[key]
        for key in (
            "runtime_root",
            "model_root",
            "state_root",
            "python_executable",
            "mode",
            "model_id",
            "hardware",
            "enhance_prompts",
            "helper_model_root",
            "helper_runtime_root",
        )
    } | {
        "revision": profile.revision,
        "runtime": profile.runtime,
        "workflow": profile.workflow,
        "recipe": hashlib.sha256(json.dumps(asdict(profile), sort_keys=True).encode()).hexdigest(),
    }


class ModelLibrary:
    def __init__(self, state_root):
        self.path = Path(state_root) / "library.json"

    def _records(self):
        records = read_json(self.path).get("models", {})
        return records if isinstance(records, dict) else {}

    def config_for(self, profile, fallback: LocalConfig):
        record = self._records().get(profile.id, {})
        if isinstance(record, dict) and isinstance(record.get("config"), dict):
            try:
                saved = LocalConfig.from_dict(record.get("config"))
                if saved.model_id == profile.id:
                    if record.get("revision") != profile.revision:
                        saved.accepted_license = ""
                    return saved
            except ManagerError:
                pass
        return replace(
            fallback,
            model_id=profile.id,
            accepted_license="",
            width=profile.default_width,
            height=profile.default_height,
            steps=profile.default_steps,
            seed=-1,
            enhance_prompts=bool(profile.enhancement),
        )

    def verified(self, config, profile):
        record = self._records().get(profile.id, {})
        return isinstance(record, dict) and record.get("connection") == connection_key(
            config, profile
        )

    def remember(self, config, profile, *, verified):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with FileLock(str(self.path.with_suffix(".lock")), timeout=5):
            records = self._records()
            records[profile.id] = {
                "config": config.to_dict(),
                "revision": profile.revision,
                "connection": connection_key(config, profile) if verified else None,
            }
            atomic_json(self.path, {"version": 1, "models": records})

    def forget(self, model_id):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with FileLock(str(self.path.with_suffix(".lock")), timeout=5):
            records = self._records()
            records.pop(model_id, None)
            atomic_json(self.path, {"version": 1, "models": records})
