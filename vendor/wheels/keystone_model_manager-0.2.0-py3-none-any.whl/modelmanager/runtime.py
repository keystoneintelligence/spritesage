"""Install a separately versioned runtime. Never install ML packages into the host app."""

import ctypes
import json
import os
import platform
import queue
import subprocess
import sys
import tarfile
import threading
import zipfile
from importlib.resources import files
from pathlib import Path

from filelock import FileLock, Timeout

from .config import LocalConfig, runtime_paths
from .storage import atomic_json, download, read_json, require_space
from .types import ManagerError, check_cancel, emit

COMFY_REVISION = "b0f4b7b294ce482a2e071d9d762c133d38c7aa07"
PYTHON_URL = "https://github.com/astral-sh/python-build-standalone/releases/download/20260901/cpython-3.12.14%2B20260901-x86_64-pc-windows-msvc-install_only_stripped.tar.gz"
PYTHON_SHA = "7c45c9622400d578709a9b2cddbe8124cc21d382409d9f13406d706d28e31b14"
PYTHON_SIZE = 21980728
COMFY_SHA = "43f64c389fb53d169a310c5c9ab94e34b546cd83e0dd6d05566aa5defb30bf62"
COMFY_SIZE = 13203090
RUNTIME_ID = f"comfy-{COMFY_REVISION}-py312-cu126-v1"


def clean_environment():
    env = os.environ.copy()
    for name in ("PYTHONHOME", "PYTHONPATH", "VIRTUAL_ENV"):
        env.pop(name, None)
    env["PYTHONNOUSERSITE"] = "1"
    bundle = getattr(sys, "_MEIPASS", None)
    if bundle:
        env["PATH"] = os.pathsep.join(
            part
            for part in env.get("PATH", "").split(os.pathsep)
            if not part.lower().startswith(str(bundle).lower())
        )
    return env


def spawn(args, **kwargs):
    """PyInstaller's DLL search directory must not leak into the external Python runtime."""
    reset = sys.platform == "win32" and getattr(sys, "frozen", False)
    if reset:
        ctypes.windll.kernel32.SetDllDirectoryW(None)
    try:
        return subprocess.Popen(
            [str(arg) for arg in args],
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
            **kwargs,
        )
    finally:
        if reset:
            ctypes.windll.kernel32.SetDllDirectoryW(str(sys._MEIPASS))


def stop_process(process):
    if process.poll() is not None:
        return
    if sys.platform == "win32":
        # Only the process we created and its descendants; no process-name/global kills.
        with spawn(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ) as killer:
            killer.wait(timeout=20)
    else:
        process.terminate()
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=10)


def run_command(args, progress=None, cancel=None, *, env=None, log_path=None):
    messages = queue.Queue()
    process = spawn(
        args,
        env=env or clean_environment(),
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
    )

    def read_output():
        for line in process.stdout:
            messages.put(line.rstrip())

    reader = threading.Thread(target=read_output, daemon=True)
    reader.start()
    tail = []
    log = Path(log_path).open("a", encoding="utf-8") if log_path else None
    try:
        while process.poll() is None or reader.is_alive() or not messages.empty():
            check_cancel(cancel)
            try:
                line = messages.get(timeout=0.2)
            except queue.Empty:
                continue
            tail.append(line)
            tail = tail[-20:]
            if log:
                log.write(line + "\n")
                log.flush()
            emit(progress, line[-300:])
        if process.wait() != 0:
            raise ManagerError(
                "Runtime setup failed. Retry after checking the setup log.\n" + "\n".join(tail[-5:])
            )
        return "\n".join(tail)
    finally:
        stop_process(process)
        reader.join(timeout=5)
        process.stdout.close()
        if log:
            log.close()


def runtime_status(config: LocalConfig):
    try:
        comfy, python = runtime_paths(config)
        if not (comfy / "main.py").is_file() or not python.is_file():
            return "Not installed"
        if (
            config.mode == "managed"
            and read_json(Path(config.runtime_root) / "runtime.json").get("id") != RUNTIME_ID
        ):
            return "Setup incomplete"
        return "Ready"
    except ManagerError:
        return "Not configured"


def safe_extract(archive: Path, destination: Path, *, strip_prefix=""):
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()

    def target(name):
        if strip_prefix:
            if not name.startswith(strip_prefix):
                raise ManagerError("Unexpected runtime archive layout.")
            name = name[len(strip_prefix) :]
        result = root / name
        if not result.resolve().is_relative_to(root):
            raise ManagerError("Runtime archive contains a path outside the installation.")
        return result

    if archive.suffix == ".zip":
        with zipfile.ZipFile(archive) as source:
            for member in source.infolist():
                path = target(member.filename)
                if (member.external_attr >> 16) & 0o170000 == 0o120000:
                    raise ManagerError("Runtime archive links are not supported.")
                if member.is_dir():
                    path.mkdir(parents=True, exist_ok=True)
                else:
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with source.open(member) as input_file, path.open("wb") as output:
                        import shutil

                        shutil.copyfileobj(input_file, output)
    else:
        with tarfile.open(archive) as source:
            for member in source:
                path = target(member.name)
                if member.isdir():
                    path.mkdir(parents=True, exist_ok=True)
                elif member.isfile():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with source.extractfile(member) as input_file, path.open("wb") as output:
                        import shutil

                        shutil.copyfileobj(input_file, output)
                else:
                    raise ManagerError(
                        "Runtime archive contains an unsupported link or special file."
                    )


def install_runtime(config: LocalConfig, progress=None, cancel=None):
    if config.mode != "managed":
        raise ManagerError("Existing runtimes are never modified. Use Verify connection instead.")
    if sys.platform != "win32" or platform.machine().lower() not in {"amd64", "x86_64"}:
        raise ManagerError(
            "Automatic runtime installation currently supports Windows x64. Use an existing ComfyUI installation on this platform."
        )
    root = Path(config.runtime_root)
    root.mkdir(parents=True, exist_ok=True)
    marker = root / ".modelmanager-runtime.json"
    if any(root.iterdir()) and read_json(marker).get("owner") != "keystone-model-manager":
        raise ManagerError(
            "Choose an empty runtime folder, or select Use an existing installation."
        )
    atomic_json(marker, {"owner": "keystone-model-manager"})
    try:
        with FileLock(str(root / ".setup.lock"), timeout=0):
            if runtime_status(config) == "Ready":
                emit(progress, "Runtime already installed")
                return
            require_space(root, 10 * 1024**3)
            archives = root / "downloads"
            python_archive = archives / "python.tar.gz"
            comfy_archive = archives / "comfy.zip"
            download(PYTHON_URL, python_archive, PYTHON_SIZE, PYTHON_SHA, progress, cancel)
            download(
                f"https://codeload.github.com/Comfy-Org/ComfyUI/zip/{COMFY_REVISION}",
                comfy_archive,
                COMFY_SIZE,
                COMFY_SHA,
                progress,
                cancel,
            )
            check_cancel(cancel)
            emit(progress, "Preparing the isolated Python runtime…")
            safe_extract(python_archive, root)
            safe_extract(comfy_archive, root / "ComfyUI", strip_prefix=f"ComfyUI-{COMFY_REVISION}/")
            comfy, python = runtime_paths(config)
            constraints = root / "constraints.txt"
            constraints.write_text(
                "torch==2.9.0+cu126\ntorchvision==0.24.0+cu126\ntorchaudio==2.9.0+cu126\n",
                encoding="utf-8",
            )
            env = clean_environment()
            env["PIP_CACHE_DIR"] = str(root / "downloads" / "pip-cache")
            log = root / "setup.log"
            emit(progress, "Installing the GPU runtime. This is a several-GiB download…")
            run_command(
                [
                    python,
                    "-m",
                    "pip",
                    "install",
                    "--disable-pip-version-check",
                    "torch==2.9.0+cu126",
                    "torchvision==0.24.0+cu126",
                    "torchaudio==2.9.0+cu126",
                    "--index-url",
                    "https://download.pytorch.org/whl/cu126",
                ],
                progress,
                cancel,
                env=env,
                log_path=log,
            )
            lock = (
                files("modelmanager")
                .joinpath("data/runtime-requirements.txt")
                .read_text(encoding="utf-8")
            )
            requirements = root / "runtime-requirements.txt"
            requirements.write_text(lock, encoding="utf-8")
            run_command(
                [
                    python,
                    "-m",
                    "pip",
                    "install",
                    "--disable-pip-version-check",
                    "-c",
                    constraints,
                    "-r",
                    requirements,
                ],
                progress,
                cancel,
                env=env,
                log_path=log,
            )
            run_command([python, "-m", "pip", "check"], progress, cancel, env=env, log_path=log)
            probe_runtime(config, progress, cancel)
            atomic_json(
                root / "runtime.json",
                {"id": RUNTIME_ID, "comfy_revision": COMFY_REVISION, "python_sha256": PYTHON_SHA},
            )
            emit(progress, "Local runtime installed", 1, 1)
    except Timeout as error:
        raise ManagerError(
            "Another setup is using this runtime folder. Wait for it to finish."
        ) from error


def probe_runtime(config: LocalConfig, progress=None, cancel=None):
    comfy, python = runtime_paths(config)
    if not (comfy / "main.py").is_file():
        raise ManagerError("ComfyUI main.py was not found. Select its installation folder.")
    output = run_command(
        [
            python,
            "-c",
            "import torch, aiohttp, transformers; import json; print(json.dumps({'torch':torch.__version__, 'cuda':torch.cuda.is_available()}))",
        ],
        progress,
        cancel,
    )
    try:
        result = json.loads(output.splitlines()[-1])
    except (ValueError, IndexError) as error:
        raise ManagerError(
            "The selected Python runtime did not pass its dependency check."
        ) from error
    if not result["cuda"] and config.hardware != "cpu":
        raise ManagerError(
            "This runtime cannot access an NVIDIA GPU. Check its PyTorch installation/driver, or explicitly select CPU mode (very slow)."
        )
    return result
