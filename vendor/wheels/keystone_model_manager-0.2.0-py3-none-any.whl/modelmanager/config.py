from dataclasses import asdict, dataclass, fields
from pathlib import Path

from platformdirs import user_data_path

from .catalog import CATALOG, get_profile
from .types import ManagerError


@dataclass
class LocalConfig:
    runtime_root: str
    model_root: str
    state_root: str
    python_executable: str = ""
    mode: str = "managed"
    model_id: str = CATALOG[0].id
    hardware: str = "auto"
    width: int = 512
    height: int = 512
    steps: int = 25
    seed: int = -1
    accepted_license: str = ""

    def to_dict(self):
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict | None):
        if data is not None and not isinstance(data, dict):
            raise ManagerError(
                "Local model settings must be an object. Set up local generation again."
            )
        result = default_config().to_dict()
        allowed = {item.name for item in fields(cls)}
        result.update({key: value for key, value in (data or {}).items() if key in allowed})
        config = cls(**result)
        config.validate()
        return config

    def validate(self):
        get_profile(self.model_id)
        if not isinstance(self.python_executable, str) or (
            self.python_executable and not Path(self.python_executable).is_absolute()
        ):
            raise ManagerError("Choose an absolute path to the Python executable.")
        if self.mode not in {"managed", "existing"}:
            raise ManagerError("Choose a managed runtime or an existing ComfyUI installation.")
        if self.hardware not in {"auto", "compatibility", "cpu"}:
            raise ManagerError("Choose a supported hardware profile.")
        for name in ("runtime_root", "model_root", "state_root"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value.strip() or not Path(value).is_absolute():
                raise ManagerError(f"Choose an absolute folder path for {name.replace('_', ' ')}.")
        for name in ("width", "height"):
            value = getattr(self, name)
            if not isinstance(value, int) or not 256 <= value <= 2048 or value % 64:
                raise ManagerError("Image dimensions must be multiples of 64 from 256 to 2048.")
        if not isinstance(self.steps, int) or not 1 <= self.steps <= 100:
            raise ManagerError("Choose between 1 and 100 generation steps.")
        if not isinstance(self.seed, int) or not -1 <= self.seed < 2**63:
            raise ManagerError("Seed must be -1 (random) or a non-negative 63-bit integer.")


def default_config() -> LocalConfig:
    base = user_data_path("Model Manager", appauthor="Keystone Intelligence")
    return LocalConfig(str(base / "runtime"), str(base / "models"), str(base / "state"))


def discover_installation(folder: str | Path) -> tuple[Path, Path | None, Path]:
    """Accept a runtime, ComfyUI folder, or its models folder without machine-specific paths."""
    selected = Path(folder).expanduser().resolve()
    candidates = (selected, selected / "ComfyUI", selected.parent)
    comfy = next(
        (path for path in candidates if (path / "main.py").is_file() and (path / "comfy").is_dir()),
        None,
    )
    if comfy is None:
        raise ManagerError(
            "Choose a ComfyUI installation folder, its models folder, or its parent."
        )
    python_candidates = (
        comfy.parent / "python" / "python.exe",
        comfy.parent / "venv" / "Scripts" / "python.exe",
        comfy.parent / "python_embeded" / "python.exe",
        comfy / ".venv" / "Scripts" / "python.exe",
        comfy.parent / "venv" / "bin" / "python",
        comfy / ".venv" / "bin" / "python",
    )
    python = next((path for path in python_candidates if path.is_file()), None)
    return comfy, python, comfy / "models"


def runtime_paths(config: LocalConfig) -> tuple[Path, Path]:
    root = Path(config.runtime_root)
    if config.mode == "managed":
        return root / "ComfyUI", root / "python" / "python.exe"
    comfy, detected, _ = discover_installation(root)
    python = Path(config.python_executable) if config.python_executable else detected
    if python is None or not python.is_file():
        raise ManagerError("Choose the Python executable used by this ComfyUI installation.")
    return comfy, python
