from dataclasses import dataclass
from threading import Event
from typing import Callable


class ManagerError(RuntimeError):
    """An actionable error suitable for display by the host application."""


class Cancelled(ManagerError):
    pass


@dataclass(frozen=True)
class Progress:
    message: str
    completed: int = 0
    total: int = 0
    detail: str = ""


ProgressCallback = Callable[[Progress], None]


def emit(callback: ProgressCallback | None, message: str, completed=0, total=0):
    if callback:
        callback(Progress(message, completed, total))


def check_cancel(cancel: Event | None):
    if cancel is not None and cancel.is_set():
        raise Cancelled("Canceled. Completed downloads are kept for the next attempt.")
