"""Optional Qt progress widgets shared by host applications."""

from threading import Event
from PySide6 import QtCore, QtWidgets


def apply_palette(widget, palette):
    if not palette:
        return
    background = palette.get("dialog_bg", palette.get("window_bg", "#3C3F41"))
    foreground = palette.get("text_color", "#BBBBBB")
    field = palette.get("dialog_input_bg", palette.get("editable_value_bg", "#313335"))
    border = palette.get("placeholder_border", "#555555")
    widget.setStyleSheet(f"""
        QDialog {{ background: {background}; color: {foreground}; }}
        QLabel, QCheckBox, QGroupBox {{ color: {foreground}; background: transparent; }}
        QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QListWidget {{
            background: {field}; color: {foreground}; border: 1px solid {border}; padding: 5px;
        }}
        QPushButton {{ background: {palette.get('button_bg', '#555555')}; color: {foreground};
            border: 1px solid {border}; border-radius: 3px; padding: 6px 12px; }}
        QPushButton:disabled {{ color: #888888; }}
        QPushButton#installModel {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; color: white; font-weight: bold; }}
        QPushButton#installModel:disabled {{ background: {palette.get('button_bg', '#555555')}; color: #888888; }}
        QPushButton#existingModel {{ background: transparent; border: none; padding: 4px 0; color: {palette.get('link_color', '#75B9EF')}; }}
        QToolButton {{ background: transparent; color: {foreground}; border: none; padding: 5px; }}
        QMenu {{ background: {background}; color: {foreground}; border: 1px solid {border}; }}
        QMenu::item:selected {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; }}
        QWidget#advancedFields, QScrollArea {{ background: {background}; border: none; }}
        QListWidget::item {{ padding: 10px 6px; }}
        QListWidget::item:selected {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; color: white; }}
        QCheckBox::indicator {{ width: 14px; height: 14px; border: 1px solid {border};
            background: {field}; }}
        QCheckBox::indicator:checked {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; }}
        QGroupBox {{ border: 1px solid {border}; margin-top: 12px; padding-top: 12px; }}
        QProgressBar {{ color: {foreground}; background: {field}; text-align: center; }}
        QProgressBar::chunk {{ background: {palette.get('tree_item_selected_bg', '#5A7E9E')}; }}
    """)


class _TaskWorker(QtCore.QObject):
    progress = QtCore.Signal(object)
    result = QtCore.Signal(object)
    error = QtCore.Signal(object)
    finished = QtCore.Signal()

    def __init__(self, task, cancel):
        super().__init__()
        self.task = task
        self.cancel = cancel

    @QtCore.Slot()
    def run(self):
        try:
            self.result.emit((self.task(self.progress.emit, self.cancel),))
        except Exception as error:
            self.error.emit(error)
        finally:
            self.finished.emit()


class TaskDialog(QtWidgets.QDialog):
    def __init__(self, parent, title, task, palette=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(520)
        apply_palette(self, palette)
        self.cancel_event = Event()
        self.value = None
        self.failure = None
        self.running = True
        layout = QtWidgets.QVBoxLayout(self)
        self.label = QtWidgets.QLabel("Preparing…")
        self.label.setWordWrap(True)
        self.bar = QtWidgets.QProgressBar()
        self.bar.setRange(0, 0)
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.request_cancel)
        self.details_toggle = QtWidgets.QToolButton()
        self.details_toggle.setText("Show details")
        self.details_toggle.setCheckable(True)
        self.details = QtWidgets.QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setMaximumBlockCount(400)
        self.details.setMaximumHeight(180)
        self.details.hide()
        self.details_toggle.toggled.connect(self.details.setVisible)
        layout.addWidget(self.label)
        layout.addWidget(self.bar)
        layout.addWidget(self.details_toggle)
        layout.addWidget(self.details)
        layout.addWidget(self.cancel_button, alignment=QtCore.Qt.AlignmentFlag.AlignRight)
        self.thread = QtCore.QThread(self)
        self.worker = _TaskWorker(task, self.cancel_event)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.update_progress)
        self.worker.result.connect(self.got_result)
        self.worker.error.connect(self.got_error)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.completed)
        QtCore.QTimer.singleShot(0, self.thread.start)

    @QtCore.Slot(object)
    def got_result(self, payload):
        self.value = payload[0]

    @QtCore.Slot(object)
    def got_error(self, error):
        self.failure = error

    @QtCore.Slot(object)
    def update_progress(self, progress):
        if self.cancel_event.is_set():
            return
        self.label.setText(progress.message)
        detail = progress.detail or progress.message
        if getattr(self, "last_detail", None) != detail:
            self.details.appendPlainText(detail)
            self.last_detail = detail
        if progress.total:
            self.bar.setRange(0, 1000)
            self.bar.setValue(min(1000, int(progress.completed * 1000 / progress.total)))
        else:
            self.bar.setRange(0, 0)

    @QtCore.Slot()
    def completed(self):
        self.running = False
        self.accept()

    def request_cancel(self):
        self.cancel_event.set()
        self.cancel_button.setEnabled(False)
        self.label.setText("Canceling and releasing resources…")

    def reject(self):
        if self.running:
            self.request_cancel()
        else:
            super().reject()

    def closeEvent(self, event):
        if self.running:
            self.request_cancel()
            event.ignore()
        else:
            super().closeEvent(event)


def run_task(parent, title, task, palette=None):
    dialog = TaskDialog(parent, title, task, palette)
    dialog.exec()
    dialog.thread.wait()
    if dialog.failure:
        raise dialog.failure
    return dialog.value
