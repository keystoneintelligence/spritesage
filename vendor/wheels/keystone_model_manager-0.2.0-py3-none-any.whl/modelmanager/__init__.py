"""Model lifecycle and local inference; importing this package never loads an AI runtime."""

from .catalog import CATALOG, ModelProfile, get_profile
from .config import LocalConfig, default_config, discover_installation
from .storage import ModelStore
from .types import Cancelled, ManagerError, Progress

__all__ = [
    "CATALOG",
    "ModelProfile",
    "get_profile",
    "LocalConfig",
    "default_config",
    "discover_installation",
    "ModelStore",
    "Cancelled",
    "ManagerError",
    "Progress",
]
