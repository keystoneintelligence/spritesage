"""Verified, resumable downloads and non-destructive reuse of external model caches."""

import hashlib
import json
import os
import shutil
import time
import urllib.error
import urllib.request
from pathlib import Path
from threading import Event
from urllib.parse import quote

from filelock import FileLock, Timeout

from .catalog import ModelProfile
from .types import ManagerError, ProgressCallback, check_cancel, emit


def atomic_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(temp, path)


def read_json(path: Path):
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def file_digest(path: Path, progress=None, cancel=None) -> str:
    digest = hashlib.sha256()
    total = path.stat().st_size
    done = 0
    last = 0.0
    with path.open("rb") as stream:
        while block := stream.read(8 * 1024**2):
            check_cancel(cancel)
            digest.update(block)
            done += len(block)
            if time.monotonic() - last > 0.2:
                emit(progress, f"Verifying {path.name}", done, total)
                last = time.monotonic()
    return digest.hexdigest()


def require_space(path: Path, size: int):
    probe = path
    while not probe.exists():
        probe = probe.parent
    needed = size + 2 * 1024**3
    if shutil.disk_usage(probe).free < needed:
        raise ManagerError(
            f"Not enough free space at {path}. Allow at least {needed / 1024**3:.1f} GiB."
        )


def download(
    url: str,
    destination: Path,
    size: int,
    sha256: str,
    progress: ProgressCallback | None = None,
    cancel: Event | None = None,
):
    """Publish a file only after SHA-256 verification. Preserve partial bytes for retry."""
    check_cancel(cancel)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        if (
            destination.stat().st_size == size
            and file_digest(destination, progress, cancel) == sha256
        ):
            return
        raise ManagerError(
            f"An unexpected file already exists at {destination}. Move it aside and retry."
        )
    part = destination.with_name(destination.name + ".partial")
    if part.is_symlink():
        raise ManagerError("A partial download cannot be a symbolic link.")
    for attempt in range(3):
        check_cancel(cancel)
        position = part.stat().st_size if part.exists() else 0
        if position > size:
            raise ManagerError(f"Partial download is larger than expected: {part}")
        require_space(destination.parent, size - position)
        if position == size:
            break
        headers = {"User-Agent": "Keystone-Model-Manager/0.1"}
        if position:
            headers["Range"] = f"bytes={position}-"
        try:
            with urllib.request.urlopen(
                urllib.request.Request(url, headers=headers), timeout=30
            ) as response:
                if position and response.status != 206:
                    # A server may ignore Range; restart this owned partial file safely.
                    position = 0
                elif position and not response.headers.get("Content-Range", "").startswith(
                    f"bytes {position}-"
                ):
                    raise ManagerError("The download server returned an unexpected byte range.")
                last = 0.0
                with part.open("ab" if position else "wb") as output:
                    while block := response.read(1024**2):
                        check_cancel(cancel)
                        if position + len(block) > size:
                            raise ManagerError(
                                "Download exceeded the catalog's expected file size."
                            )
                        output.write(block)
                        position += len(block)
                        if time.monotonic() - last > 0.2:
                            emit(progress, f"Downloading {destination.name}", position, size)
                            last = time.monotonic()
            if position == size:
                break
        except (OSError, urllib.error.URLError) as error:
            if attempt == 2:
                raise ManagerError(f"Download interrupted: {error}. Retry to resume.") from error
            emit(progress, "Connection interrupted. Retrying download…")
    if not part.exists() or part.stat().st_size != size:
        raise ManagerError("Download is incomplete. Retry to resume.")
    if file_digest(part, progress, cancel) != sha256:
        part.unlink()  # Only the downloader's partial file; never an installed/shared file.
        raise ManagerError("Download failed its checksum check. Retry to download a clean copy.")
    check_cancel(cancel)
    os.replace(part, destination)


class ModelStore:
    def __init__(self, model_root: str | Path, state_root: str | Path):
        self.root = Path(model_root).expanduser().absolute()
        self.state = Path(state_root).expanduser().absolute()

    def managed_folder(self, profile: ModelProfile) -> Path:
        return self.root / profile.id / profile.revision

    def _roots(self, profile: ModelProfile):
        repo = "models--" + profile.repository.replace("/", "--")
        return (
            self.managed_folder(profile),
            self.root,
            self.root / "models",
            self.root / "ComfyUI" / "models",
            self.root / repo / "snapshots" / profile.revision,
            self.root / "hub" / repo / "snapshots" / profile.revision,
        )

    def locate(self, profile: ModelProfile) -> dict[str, Path]:
        result = {}
        for item in profile.files:
            for base in self._roots(profile):
                path = base / item.path
                if path.is_file():
                    result[item.path] = path
                    break
        return result

    def _receipt(self, profile: ModelProfile):
        key = hashlib.sha256(str(self.root.resolve()).encode()).hexdigest()[:24]
        return self.state / "verified" / f"{profile.id}-{key}.json"

    def remaining_bytes(self, profile: ModelProfile):
        if len(self.locate(profile)) == len(profile.files):
            return 0
        folder = self.managed_folder(profile)
        total = 0
        for item in profile.files:
            path = folder / item.path
            partial = path.with_name(path.name + ".partial")
            present = (
                path.stat().st_size
                if path.is_file()
                else (partial.stat().st_size if partial.is_file() else 0)
            )
            total += max(0, item.size - present)
        return total

    @staticmethod
    def _stamp(path: Path):
        stat = path.stat()
        return {"path": str(path.resolve()), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns}

    def status(self, profile: ModelProfile) -> str:
        files = self.locate(profile)
        if not files:
            if any(
                (self.managed_folder(profile) / (item.path + ".partial")).is_file()
                for item in profile.files
            ):
                return "Incomplete"
            return "Not installed"
        if len(files) != len(profile.files):
            return "Incomplete"
        try:
            if any(files[item.path].stat().st_size != item.size for item in profile.files):
                return "Incomplete"
            receipt = read_json(self._receipt(profile))
            expected = {item.path: self._stamp(files[item.path]) for item in profile.files}
            if (
                receipt.get("revision") == profile.revision
                and receipt.get("files") == expected
                and receipt.get("hashes") == {item.path: item.sha256 for item in profile.files}
            ):
                return "Ready"
        except OSError:
            return "Incomplete"
        return "Needs verification"

    def verify(self, profile: ModelProfile, progress=None, cancel=None):
        files = self.locate(profile)
        stamps = {}
        for item in profile.files:
            check_cancel(cancel)
            path = files.get(item.path)
            if path is None:
                raise ManagerError(
                    f"Missing {item.path}. Install the model or select its model folder."
                )
            before = self._stamp(path)
            if before["size"] != item.size or file_digest(path, progress, cancel) != item.sha256:
                raise ManagerError(
                    f"{path.name} does not match the pinned model revision. No files were changed."
                )
            if self._stamp(path) != before:
                raise ManagerError(
                    "A model file changed during verification. Retry when other downloads finish."
                )
            stamps[item.path] = before
        atomic_json(
            self._receipt(profile),
            {
                "revision": profile.revision,
                "files": stamps,
                "hashes": {item.path: item.sha256 for item in profile.files},
            },
        )
        emit(progress, "Model files verified", 1, 1)
        return files

    def install(self, profile: ModelProfile, progress=None, cancel=None):
        self.root.mkdir(parents=True, exist_ok=True)
        try:
            with FileLock(str(self.root / ".modelmanager-download.lock"), timeout=0):
                self._install(profile, progress, cancel)
        except Timeout as error:
            raise ManagerError(
                "Another application is installing into this model cache. Try again when it finishes."
            ) from error

    def _install(self, profile, progress, cancel):
        folder = self.managed_folder(profile)
        # An existing complete external model is adopted by verification, with no copy.
        if len(self.locate(profile)) == len(profile.files):
            self.verify(profile, progress, cancel)
            return
        self._assert_managed_path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        marker = folder / ".modelmanager-owned.json"
        if any(folder.iterdir()) and not marker.is_file():
            raise ManagerError(
                "This model directory contains unowned files. Choose a different model cache."
            )
        atomic_json(marker, {"model": profile.id, "revision": profile.revision})
        for item in profile.files:
            url = f"https://huggingface.co/{profile.repository}/resolve/{profile.revision}/{quote(item.path)}"
            download(url, folder / item.path, item.size, item.sha256, progress, cancel)
        self.verify(profile, progress, cancel)

    def owns(self, profile):
        return read_json(self.managed_folder(profile) / ".modelmanager-owned.json") == {
            "model": profile.id,
            "revision": profile.revision,
        }

    def _assert_managed_path(self, path: Path):
        if (
            not path.resolve().is_relative_to(self.root.resolve())
            or path.resolve() == self.root.resolve()
        ):
            raise ManagerError("Model path is outside the selected cache.")
        current = path
        while current != self.root:
            if current.is_symlink() or (
                current.exists() and current.resolve() != current.absolute()
            ):
                raise ManagerError(
                    "Managed installation paths cannot redirect to another directory."
                )
            current = current.parent

    def remove(self, profile):
        """Delete only exact owned catalog files. Borrowed installations are never deleted."""
        folder = self.managed_folder(profile)
        self._assert_managed_path(folder)
        if not self.owns(profile):
            raise ManagerError(
                "This model is shared or externally installed. Disconnect it instead; its files are not managed here."
            )
        with FileLock(str(self.root / ".modelmanager-download.lock"), timeout=0):
            for item in profile.files:
                path = folder / item.path
                self._assert_managed_path(path)
                if path.exists():
                    path.unlink()
                partial = path.with_name(path.name + ".partial")
                self._assert_managed_path(partial)
                if partial.exists():
                    partial.unlink()
            receipt = self._receipt(profile)
            if receipt.exists():
                receipt.unlink()
